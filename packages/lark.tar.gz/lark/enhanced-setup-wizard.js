/**
 * 飞书技能增强版配置向导
 *
 * 实现私人应用配置模式，提供三种配置方式：
 * 1. 免费版：交互式配置向导
 * 2. 标准版：淘宝服务（付费）
 * 3. 旗舰版：批量配置（付费）
 *
 * @version 1.7.0
 * @date 2026-02-08
 */

const fs = require('fs');
const path = require('path');
const os = require('os');

/**
 * 增强版交互式配置向导
 */
class EnhancedSetupWizard {
  constructor() {
    this.configDir = path.join(os.homedir(), '.openclaw/skills/lark');
    this.configPath = path.join(this.configDir, 'config/app.json');
    this.wizardStatePath = path.join(this.configDir, 'wizard_state.json');
  }

  /**
   * 显示初始配置选项
   */
  async showInitialOptions() {
    return {
      success: true,
      response: `🔐 检测到您还未配置飞书应用

飞书技能需要您创建自己的私人应用才能使用。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🤔 为什么需要私人应用？

• 🔒 您的数据完全私密，不会上传到任何服务器
• 👤 应用完全属于您，即使 JarvisMolt 倒闭也能继续使用
• 🎯 符合"私人助手"的设计理念
• ✅ 完全本地化，无需依赖外部服务

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📋 选择配置方式：

1️⃣ 自己配置（免费，10-15 分钟）
   ✓ 完全免费
   ✓ 学习整个流程
   ✓ 适合有一定技术基础的用户

   回复："飞书开始配置"

2️⃣ 购买授权（支付宝/微信扫码，即买即用）
   ✓ 月卡 ¥29.9 / 季卡 ¥79.9 / 年卡 ¥199
   ✓ 扫码支付，自动激活
   ✓ 适合想快速开始使用的用户

   回复："飞书购买"

3️⃣ 旗舰版（¥999/年起，支持 10 人）
   ✓ 企业统一配置
   ✓ 员工直接使用
   ✓ 专属客服支持
   ✓ 适合企业团队使用

   回复："飞书旗舰版"

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💡 提示：如果您已经有 App ID 和 Secret，可以直接配置：
   "飞书配置 App ID: cli_xxx Secret: xxx"`
    };
  }

  /**
   * 开始分步配置流程
   */
  async startStepByStep() {
    // 保存向导状态
    this.saveWizardState({ step: 1, startTime: Date.now() });

    return {
      success: true,
      response: `🚀 开始配置飞书私人应用

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📝 第 1 步：创建飞书应用（共 5 步）

请按照以下步骤操作：

1. 打开浏览器，访问飞书开放平台：
   🔗 https://open.feishu.cn/app

2. 使用您的飞书账号登录

3. 点击页面右上角的 "创建企业自建应用" 按钮

4. 填写应用信息：
   • 应用名称：OpenClaw 飞书助手
   • 应用描述：私人 AI 助手
   • 应用图标：可选（可以稍后上传）

5. 点击 "创建" 按钮

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📸 需要图文教程？
   （图文教程即将上线）

❓ 遇到问题？常见问题：
   • 没有飞书账号？先注册：https://www.feishu.cn/
   • 找不到创建按钮？确保已登录企业管理员账号
   • 创建失败？检查是否有创建应用的权限

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✅ 完成后，请回复："已创建"
⏸️  暂停配置，请回复："飞书暂停配置"
🔄 重新开始，请回复："飞书重新配置"`
    };
  }

  /**
   * 第 2 步：申请权限
   */
  async step2ApplyPermissions() {
    this.saveWizardState({ step: 2, timestamp: Date.now() });

    return {
      success: true,
      response: `⚙️ 第 2 步：申请权限（共 5 步）

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

请在应用管理页面申请以下权限：

1. 在左侧菜单中，点击 "权限管理"

2. 搜索并申请以下 9 个必需权限：

   ✅ approval:approval:readonly - 审批流程查询
   ✅ bitable:app - 多维表格操作
   ✅ calendar:calendar:readonly - 日程管理
   ✅ contact:contact.base:readonly - 获取通讯录基础信息（群聊场景需要）
   ✅ contact:user.base:readonly - 获取用户基本信息
   ✅ docx:document - 文档读写
   ✅ drive:drive - 云空间管理
   ✅ search:docs:read - 搜索云文档
   ✅ wiki:wiki:readonly - 知识库访问

3. 点击每个权限后面的 "申请" 按钮

4. 填写申请理由（例如：个人 AI 助手使用）

5. 提交申请

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⚠️ 重要提示：
• 以上 9 个权限全部必须申请，否则对应功能无法使用
• 企业自建应用的权限通常会自动通过

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📸 需要图文教程？
   （图文教程即将上线）

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✅ 完成后，请回复："已申请"
⬅️  返回上一步，请回复："飞书上一步"
⏸️  暂停配置，请回复："飞书暂停配置"`
    };
  }

  /**
   * 第 3 步：配置回调地址
   */
  async step3ConfigureCallback() {
    this.saveWizardState({ step: 3, timestamp: Date.now() });

    return {
      success: true,
      response: `🔐 第 3 步：配置回调地址（共 5 步）

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

请配置 OAuth 回调地址：

1. 在左侧菜单中，点击 "安全设置"

2. 找到 "重定向 URL" 或 "Redirect URL" 配置项

3. 点击 "添加" 或 "编辑" 按钮

4. 输入以下回调地址：

   📋 https://oauth-callback-bchxphkcet.cn-shanghai.fcapp.run/callback

   （请完整复制，包括 https:// 前缀）

5. 点击 "保存" 按钮

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⚠️ 重要提示：
• 回调地址必须完全一致，一个字符都不能错
• 这是云端回调服务，授权完成后会自动显示 Token

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📸 需要图文教程？
   （图文教程即将上线）

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✅ 完成后，请回复："已配置"
⬅️  返回上一步，请回复："飞书上一步"
⏸️  暂停配置，请回复："飞书暂停配置"`
    };
  }

  /**
   * 第 4 步：获取凭证
   */
  async step4GetCredentials() {
    this.saveWizardState({ step: 4, timestamp: Date.now() });

    return {
      success: true,
      response: `🔑 第 4 步：获取凭证（共 5 步）

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

请获取应用凭证：

1. 在左侧菜单中，点击 "凭证与基础信息"

2. 找到以下两个重要信息：

   📋 App ID（应用 ID）
   • 格式：cli_xxxxxxxxxxxxxxxx
   • 位置：页面顶部，"App ID" 标签下
   • 操作：点击复制按钮

   🔐 App Secret（应用密钥）
   • 格式：32 位字符串
   • 位置："App Secret" 标签下
   • 操作：点击 "查看" 按钮，然后复制

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⚠️ 安全提示：
• App Secret 是敏感信息，请妥善保管
• 不要将 Secret 分享给他人
• 如果泄露，请立即在飞书平台重置

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📸 需要图文教程？
   （图文教程即将上线）

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✅ 获取到凭证后，请按以下格式回复：

   飞书配置 App ID: cli_xxx Secret: xxx

   （请将 cli_xxx 和 xxx 替换为您实际的凭证）

⬅️  返回上一步，请回复："飞书上一步"
⏸️  暂停配置，请回复："飞书暂停配置"`
    };
  }

  /**
   * 第 5 步：验证配置
   */
  async step5ValidateConfig(appId, appSecret) {
    this.saveWizardState({ step: 5, timestamp: Date.now(), appId });

    // 保存配置
    const config = {
      appId,
      appSecret,
      redirectUri: 'https://oauth-callback-bchxphkcet.cn-shanghai.fcapp.run/callback',
      source: 'interactive_wizard',
      createdAt: Date.now(),
      metadata: {
        wizardVersion: '1.4.0',
        completedSteps: 5
      }
    };

    try {
      this.saveConfig(config);

      return {
        success: true,
        response: `✅ 第 5 步：配置完成！（共 5 步）

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🎉 恭喜！您的飞书私人应用配置成功！

📋 配置信息：
• App ID: ${appId}
• App Secret: ${appSecret.substring(0, 8)}...（已加密保存）
• 回调地址: https://oauth-callback-bchxphkcet.cn-shanghai.fcapp.run/callback
• 存储位置: ${this.configPath}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🔒 隐私保护：
• ✅ 这是您的私人应用，完全属于您
• ✅ 数据完全私密，不会上传到任何服务器
• ✅ 凭证已使用 AES-256 加密保存在本地
• ✅ 即使 JarvisMolt 倒闭，您仍可继续使用

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🚀 下一步：开始授权

现在您需要授权应用访问您的飞书数据：

1. 请回复："飞书授权"
2. 系统会打开浏览器进行 OAuth 授权
3. 在飞书页面点击"同意授权"
4. 复制授权码并回复："飞书授权码 xxx"

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💡 配置完成后，您可以：
• 飞书搜索文档 [关键词] - 搜索文档
• 飞书读取文档 [文档名] - 读取文档内容
• 飞书总结文档 [文档名] - AI 总结文档
• 飞书帮助 - 查看所有命令

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📊 配置统计：
• 总耗时: ${this.getElapsedTime()} 分钟
• 完成步骤: 5/5
• 配置方式: 交互式向导

感谢您选择 OpenClaw！🎊`
      };
    } catch (error) {
      return {
        success: false,
        response: `❌ 保存配置失败

错误信息: ${error.message}

可能的原因：
• 文件权限不足
• 磁盘空间不足
• 配置目录不存在

解决方案：
1. 检查 ${this.configDir} 目录权限
2. 确保有足够的磁盘空间
3. 尝试手动创建配置目录

需要帮助？请联系技术支持：
• 微信：JarvisMolt-Skills`
      };
    }
  }

  /**
   * 显示购买服务信息
   */
  async showPurchaseService() {
    return {
      success: true,
      response: `💰 购买配置服务

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

我们提供专业的配置服务，帮您快速完成配置：

📦 基础版 - ¥29.9
• OpenClaw 安装指导
• 飞书应用创建协助
• 基础配置支持
• 7 天售后支持

📦 标准版 - ¥59.9（推荐）
• 包含基础版所有内容
• 远程桌面协助
• 配置验证测试
• 30 天售后支持

📦 专业版 - ¥99.9
• 包含标准版所有内容
• 多技能配置（飞书 + 其他）
• 定制化配置
• 90 天售后支持

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🛒 购买方式：

1. 淘宝店铺：
   🔗 （即将上线，请联系微信 JarvisMolt-Skills）

2. 微信客服：
   添加微信：JarvisMolt-Skills
   发送：购买飞书配置服务

3. 扫码购买：
   [二维码图片]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⏱️ 服务流程：

1. 下单支付
2. 5 分钟内客服联系
3. 远程协助配置（10-15 分钟）
4. 配置验证测试
5. 交付配置文件
6. 售后支持

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💡 提示：
• 配置完成后，应用完全属于您
• 数据完全私密，不经过我们服务器
• 一次配置，长期使用

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🔙 返回配置选项，请回复："飞书配置"`
    };
  }

  /**
   * 显示旗舰版信息
   */
  async showEnterpriseEdition() {
    return {
      success: true,
      response: `🏢 旗舰版方案

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

为企业团队提供统一配置和管理服务：

📦 旗舰版 - ¥999/年
• 支持 10 个用户
• 企业统一配置
• 管理后台
• 批量操作
• 专属客服支持
• 99% SLA 保障

📦 旗舰版 Pro - ¥2,999/年
• 支持 50 个用户
• 包含旗舰版所有功能
• 技术顾问支持
• 定制开发
• 99.9% SLA 保障
• 优先技术支持

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✨ 旗舰版特色功能：

1. 统一配置管理
   • 企业管理员创建企业应用
   • 批量配置员工账号
   • 统一权限管理

2. 管理后台
   • 用户管理
   • 配置管理
   • 使用统计
   • 日志审计

3. 批量操作
   • 批量添加用户
   • 批量配置权限
   • 批量更新配置

4. 企业级支持
   • 专属客服
   • 技术顾问
   • 定制开发
   • SLA 保障

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📞 联系我们：

• 微信客服：JarvisMolt-Skills
• （更多联系方式即将上线）

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🎯 适合场景：
• 10 人以上的团队
• 需要统一管理的企业
• 对数据安全有高要求的企业
• 需要技术支持的企业

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🔙 返回配置选项，请回复："飞书配置"`
    };
  }

  /**
   * 保存配置
   */
  saveConfig(config) {
    const configDir = path.dirname(this.configPath);
    if (!fs.existsSync(configDir)) {
      fs.mkdirSync(configDir, { recursive: true });
    }
    fs.writeFileSync(this.configPath, JSON.stringify(config, null, 2));
  }

  /**
   * 保存向导状态
   */
  saveWizardState(state) {
    const stateDir = path.dirname(this.wizardStatePath);
    if (!fs.existsSync(stateDir)) {
      fs.mkdirSync(stateDir, { recursive: true });
    }
    fs.writeFileSync(this.wizardStatePath, JSON.stringify(state, null, 2));
  }

  /**
   * 加载向导状态
   */
  loadWizardState() {
    try {
      if (fs.existsSync(this.wizardStatePath)) {
        const content = fs.readFileSync(this.wizardStatePath, 'utf-8');
        return JSON.parse(content);
      }
    } catch (error) {
      // 忽略错误
    }
    return null;
  }

  /**
   * 清除向导状态
   */
  clearWizardState() {
    try {
      if (fs.existsSync(this.wizardStatePath)) {
        fs.unlinkSync(this.wizardStatePath);
      }
    } catch (error) {
      // 忽略错误
    }
  }

  /**
   * 获取配置耗时
   */
  getElapsedTime() {
    const state = this.loadWizardState();
    if (state && state.startTime) {
      const elapsed = Date.now() - state.startTime;
      return Math.round(elapsed / 60000); // 转换为分钟
    }
    return 0;
  }

  /**
   * 恢复配置进度
   */
  async resumeSetup() {
    const state = this.loadWizardState();
    if (!state) {
      return this.showInitialOptions();
    }

    const step = state.step || 1;
    const elapsed = this.getElapsedTime();

    return {
      success: true,
      response: `🔄 检测到未完成的配置

您上次配置到第 ${step} 步，已过去 ${elapsed} 分钟。

是否继续配置？

• 继续配置：回复 "飞书继续配置"
• 重新开始：回复 "飞书重新配置"
• 放弃配置：回复 "飞书放弃配置"`
    };
  }
}

module.exports = EnhancedSetupWizard;
