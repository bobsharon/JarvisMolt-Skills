/**
 * 核心文档处理器 — 搜索、列表、读取、总结、批量操作
 *
 * 从 agent.js 提取，使用 withAuth 消除授权样板代码。
 * 每个 handler 的最后一个参数是 deps，由 withAuth 注入 api。
 *
 * deps 结构：
 *   { ensureAuthorized, loadTokens, FeishuAPI, api, cache, logger,
 *     getSummaryService, context }
 */

const fs = require('fs');
const path = require('path');
const os = require('os');

const { withAuth } = require('../lib/with-auth');
const { formatTime, truncate, extractSummary, extractKeywords } = require('../utils');

// ============== 辅助函数 ==============

/**
 * 获取文档类型图标
 */
function getFileIcon(type) {
  const icons = {
    'docx': '📄',
    'sheet': '📊',
    'mindnote': '🧠',
    'bitable': '📋',
    'file': '📁'
  };
  return icons[type] || '📄';
}

/**
 * 格式化为 Markdown
 */
function formatAsMarkdown(content, docName) {
  let md = `# ${docName}\n\n`;
  md += content;
  return md;
}

// ============== 搜索 ==============

async function _handleSearch(query, options, deps) {
  const { api, cache, logger } = deps;

  // 检查缓存
  const cacheKey = `search:${query}`;
  let files = cache.get(cacheKey);

  if (!files) {
    const result = await api.searchDocuments(query, { pageSize: 20 });
    files = result.files || [];
    cache.set(cacheKey, files);
  }

  if (files.length === 0) {
    return {
      success: true,
      response: `未找到包含"${query}"的文档。\n\n建议：\n• 尝试不同的关键词\n• 检查是否有权限访问该文档\n• 使用更通用的词汇`
    };
  }

  let response = `🔍 找到 ${files.length} 个相关文档：\n\n`;

  files.slice(0, 10).forEach((file, index) => {
    const icon = getFileIcon(file.type);

    response += `${index + 1}. ${icon} ${file.name}\n`;

    if (file.owner_name) {
      response += `   👤 ${file.owner_name}`;
    }
    if (file.edit_time) {
      response += ` · ${formatTime(file.edit_time)}`;
    }
    response += '\n';

    if (file.url) {
      response += `   🔗 ${truncate(file.url, 60)}\n`;
    }
    response += '\n';
  });

  if (files.length > 10) {
    response += `... 还有 ${files.length - 10} 个结果\n\n`;
  }

  response += '你可以使用"飞书读取文档 <文档名>"查看详细内容。';

  logger.info('文档搜索', { query, results: files.length });
  return { success: true, response };
}

// ============== 列表 ==============

async function _handleList(deps) {
  const { api, cache, logger } = deps;

  // 检查缓存
  const cacheKey = 'my_files';
  let files = cache.get(cacheKey);

  if (!files) {
    const result = await api.listMyFiles({ pageSize: 20 });
    files = result.files || [];
    cache.set(cacheKey, files);
  }

  if (files.length === 0) {
    return {
      success: true,
      response: '📂 你的云空间暂无文档。'
    };
  }

  let response = `📂 你的云空间文档（最近 ${files.length} 个）：\n\n`;

  files.forEach((file, index) => {
    const icon = getFileIcon(file.type);

    response += `${index + 1}. ${icon} ${file.name}`;
    if (file.edit_time) {
      response += ` · ${formatTime(file.edit_time)}`;
    }
    response += '\n';
  });

  response += '\n💡 提示：使用"飞书搜索文档 <关键词>"查找特定文档';

  return { success: true, response };
}

// ============== 读取文档 ==============

async function _handleRead(docName, options, deps) {
  const { api, cache, logger } = deps;

  // 先搜索文档
  const searchResult = await api.searchDocuments(docName, { pageSize: 5 });
  const files = searchResult.files || [];

  if (files.length === 0) {
    return {
      success: false,
      response: `未找到名为"${docName}"的文档。`
    };
  }

  // 找最匹配的文档
  const doc = files.find(f =>
    f.name.toLowerCase() === docName.toLowerCase() ||
    f.name.toLowerCase().includes(docName.toLowerCase())
  ) || files[0];

  // 获取文档详情
  const cacheKey = `doc:${doc.token}`;
  let docInfo = cache.get(cacheKey);

  if (!docInfo) {
    docInfo = await api.getDocumentContent(doc.token, doc.type);
    cache.set(cacheKey, docInfo);
  }

  // 构建响应
  let response = `📄 ${doc.name}\n`;
  response += `${'='.repeat(doc.name.length + 2)}\n\n`;

  if (doc.type) {
    const typeMap = {
      'docx': '文档',
      'doc': '旧版文档',
      'sheet': '表格',
      'mindnote': '思维笔记',
      'bitable': '多维表格',
      'file': '文件'
    };
    response += `类型：${typeMap[doc.type] || doc.type}\n`;
  }

  if (doc.owner_name) {
    response += `创建者：${doc.owner_name}\n`;
  }
  if (doc.create_time) {
    response += `创建时间：${formatTime(doc.create_time)}\n`;
  }
  if (doc.edit_time) {
    response += `最后修改：${formatTime(doc.edit_time)}\n`;
  }

  response += '\n';

  // 显示内容摘要
  if (docInfo.content) {
    response += '📝 内容摘要：\n';
    response += '-'.repeat(40) + '\n';

    const summary = extractSummary(docInfo.content, 800);
    response += summary + '\n';

    // 提取关键词
    const keywords = extractKeywords(docInfo.content, 5);
    if (keywords.length > 0) {
      response += `\n🏷️ 关键词：${keywords.join('、')}\n`;
    }

    response += '-'.repeat(40) + '\n';
  } else if (docInfo.meta) {
    response += '💡 提示：该文档类型暂不支持内容提取，仅显示元信息。\n';
  }

  if (doc.url) {
    response += `\n🔗 在线查看：${doc.url}\n`;
  }

  logger.info('读取文档', { docName, docToken: doc.token });
  return { success: true, response };
}

// ============== 总结文档 ==============

async function _handleSummarize(docName, context, deps) {
  const { api, logger, getSummaryService } = deps;

  // 先搜索文档
  const searchResult = await api.searchDocuments(docName, { pageSize: 5 });
  const files = searchResult.files || [];

  if (files.length === 0) {
    return {
      success: false,
      response: `未找到文档"${docName}"。\n\n建议：\n• 检查文档名称是否正确\n• 使用"飞书搜索文档 ${docName}"查看相关文档`
    };
  }

  // 使用第一个匹配的文档
  const doc = files[0];

  // 获取文档内容
  let content = '';
  try {
    const docInfo = await api.getDocumentContent(doc.token, doc.type);
    content = docInfo.content || '';
  } catch (error) {
    logger.warn('获取文档内容失败', { error: error.message, docToken: doc.token });
    return {
      success: false,
      response: `无法获取文档内容：${error.message}`
    };
  }

  if (!content || content.trim().length === 0) {
    return {
      success: false,
      response: `文档"${doc.name}"内容为空或无法提取。`
    };
  }

  // 使用智能总结服务（传入 context）
  const service = getSummaryService(context);
  const summaryResult = await service.summarize(content, {
    maxLength: 500,
    language: 'auto',
    style: 'concise'
  });

  const keywords = await service.getKeywords(content, 5);
  const providerInfo = service.getProviderInfo();
  // 格式化输出
  let response = `📄 ${doc.name}\n`;
  response += '='.repeat(40) + '\n\n';

  // 显示提供商信息
  if (providerInfo.name === 'OpenAI' || providerInfo.name === 'OpenClaw') {
    response += `🤖 智能总结 (由 ${providerInfo.model} 生成):\n\n`;
  } else {
    response += `📝 文档总结:\n\n`;
  }

  response += summaryResult.summary + '\n\n';

  if (keywords && keywords.length > 0) {
    response += `🏷️ 关键词: ${keywords.join('、')}\n\n`;
  }

  // 显示元信息
  response += '-'.repeat(40) + '\n';
  if (doc.owner_name) {
    response += `👤 创建者: ${doc.owner_name}\n`;
  }
  if (doc.edit_time) {
    response += `📅 最后修改: ${formatTime(doc.edit_time)}\n`;
  }
  if (doc.url) {
    response += `🔗 链接: ${doc.url}\n`;
  }

  // 显示总结信息
  if (providerInfo.name === 'OpenClaw') {
    response += `\n✨ 由 OpenClaw 主模型生成`;
    if (summaryResult.tokens) {
      response += ` | 使用了 ${summaryResult.tokens} tokens`;
    }
  } else if (providerInfo.name === 'OpenAI' && summaryResult.tokens) {
    response += `\n✨ 由 ${providerInfo.model} 生成 | 使用了 ${summaryResult.tokens} tokens`;
  } else if (providerInfo.provider === 'basic') {
    response += `\n💡 提示: 使用 OpenClaw 主模型可获得更高质量的智能总结`;
  }

  logger.info('文档总结', { docName, docToken: doc.token, provider: providerInfo.name || providerInfo.provider });
  return { success: true, response };
}

// ============== 批量搜索 ==============

async function _handleBatchSearch(queries, deps) {
  const { api, logger } = deps;

  const results = new Map();
  const seenTokens = new Set();

  console.log('🔍 批量搜索中...\n');

  // 并发搜索
  const searchPromises = queries.map(async (query) => {
    try {
      process.stdout.write(`正在搜索: ${query} `);

      const searchResult = await api.searchDocuments(query.trim(), { pageSize: 20 });
      const files = searchResult.files || [];

      // 去重
      const uniqueFiles = files.filter(file => {
        if (seenTokens.has(file.token)) {
          return false;
        }
        seenTokens.add(file.token);
        return true;
      });

      results.set(query, uniqueFiles);
      console.log(`✅ 找到 ${uniqueFiles.length} 个`);
    } catch (error) {
      results.set(query, []);
      console.log(`❌ 搜索失败: ${error.message}`);
    }
  });

  await Promise.all(searchPromises);

  // 格式化输出
  let response = '\n📊 批量搜索完成！';
  const totalCount = Array.from(results.values()).reduce((sum, files) => sum + files.length, 0);
  response += `共找到 ${totalCount} 个文档（已去重）\n\n`;

  for (const [query, files] of results) {
    if (files.length > 0) {
      response += `【${query}】(${files.length} 个)\n`;
      files.slice(0, 5).forEach((file, index) => {
        const icon = getFileIcon(file.type);
        response += `${index + 1}. ${icon} ${file.name}\n`;
      });
      if (files.length > 5) {
        response += `... 还有 ${files.length - 5} 个\n`;
      }
      response += '\n';
    }
  }

  response += '💡 提示: 使用"飞书批量总结 文档1,文档2"可以一次性总结多个文档';

  logger.info('批量搜索', { queries: queries.length, total: totalCount });
  return {
    success: true,
    response,
    results: Array.from(results.entries())
  };
}

// ============== 批量总结 ==============

async function _handleBatchSummarize(docNames, context, deps) {
  const { logger } = deps;

  const results = [];

  console.log('📝 批量总结中...\n');

  // 串行处理（避免 API 限流）
  for (let i = 0; i < docNames.length; i++) {
    const docName = docNames[i].trim();
    try {
      process.stdout.write(`[${i + 1}/${docNames.length}] 正在总结: ${docName} `);

      // 调用内部 _handleSummarize，直接传 deps（已含 api）
      const result = await _handleSummarize(docName, context, deps);

      if (result.success) {
        results.push({
          name: docName,
          summary: result.response,
          success: true
        });
        console.log('✅');
      } else {
        results.push({
          name: docName,
          error: result.response,
          success: false
        });
        console.log('❌');
      }
    } catch (error) {
      results.push({
        name: docName,
        error: error.message,
        success: false
      });
      console.log(`❌ ${error.message}`);
    }

    // 延迟避免限流
    if (i < docNames.length - 1) {
      await new Promise(resolve => setTimeout(resolve, 500));
    }
  }

  // 格式化输出
  let response = '\n📊 批量总结完成！\n\n';
  for (const result of results) {
    response += '━'.repeat(40) + '\n';
    response += `📄 ${result.name}\n`;
    response += '━'.repeat(40) + '\n';

    if (result.success) {
      // 提取总结内容（去掉元信息）
      const summaryMatch = result.summary.match(/🤖 智能总结.*?\n\n([\s\S]*?)\n\n🏷️/);
      if (summaryMatch) {
        response += summaryMatch[1] + '\n';
      } else {
        response += result.summary + '\n';
      }
    } else {
      response += `❌ 总结失败: ${result.error}\n`;
    }

    response += '\n';
  }

  const successCount = results.filter(r => r.success).length;
  response += `✅ 成功: ${successCount}/${results.length}\n`;
  response += '\n💡 提示: 使用"飞书批量导出"可以保存为文件';

  logger.info('批量总结', { total: docNames.length, success: successCount });
  return {
    success: true,
    response,
    results
  };
}

// ============== 批量导出 ==============

async function _handleBatchExport(docNames, format, deps) {
  const { logger } = deps;

  const exportDir = path.join(
    os.homedir(),
    'Downloads',
    `feishu-export-${new Date().toISOString().split('T')[0].replace(/-/g, '')}`
  );

  // 创建导出目录
  if (!fs.existsSync(exportDir)) {
    fs.mkdirSync(exportDir, { recursive: true });
  }

  const results = [];

  console.log('📦 批量导出中...\n');

  for (let i = 0; i < docNames.length; i++) {
    const docName = docNames[i].trim();
    try {
      process.stdout.write(`[${i + 1}/${docNames.length}] 正在导出: ${docName} `);

      // 调用内部 _handleRead，直接传 deps（已含 api）
      const result = await _handleRead(docName, {}, deps);

      if (result.success && result.response) {
        // 根据格式导出
        let fileName, content;

        if (format === 'markdown' || format === 'md') {
          fileName = `${docName}.md`;
          content = formatAsMarkdown(result.response, docName);
        } else if (format === 'json') {
          fileName = `${docName}.json`;
          content = JSON.stringify({ name: docName, content: result.response }, null, 2);
        } else {
          fileName = `${docName}.txt`;
          content = result.response;
        }

        const filePath = path.join(exportDir, fileName);
        fs.writeFileSync(filePath, content, 'utf8');

        results.push({
          name: docName,
          path: filePath,
          success: true
        });
        console.log('✅');
      } else {
        results.push({
          name: docName,
          error: '获取文档失败',
          success: false
        });
        console.log('❌');
      }
    } catch (error) {
      results.push({
        name: docName,
        error: error.message,
        success: false
      });
      console.log(`❌ ${error.message}`);
    }
  }

  // 格式化输出
  const successCount = results.filter(r => r.success).length;

  let response = '\n✅ 导出完成！\n\n';
  response += `已保存到: ${exportDir}/\n`;

  results.filter(r => r.success).forEach(r => {
    response += `├── ${path.basename(r.path)}\n`;
  });

  response += `\n共导出 ${successCount} 个文档`;

  if (successCount < results.length) {
    response += `\n⚠️ ${results.length - successCount} 个文档导出失败`;
  }

  logger.info('批量导出', { total: docNames.length, success: successCount, dir: exportDir });
  return {
    success: true,
    response,
    exportDir,
    results
  };
}

// ============== 导出（使用 withAuth 包装） ==============

module.exports = {
  handleSearch:         withAuth(_handleSearch, '云文档搜索'),
  handleList:           withAuth(_handleList, '列出文档'),
  handleRead:           withAuth(_handleRead, '读取文档'),
  handleSummarize:      withAuth(_handleSummarize, '总结文档'),
  handleBatchSearch:    withAuth(_handleBatchSearch, '批量搜索'),
  handleBatchSummarize: withAuth(_handleBatchSummarize, '批量总结'),
  handleBatchExport:    withAuth(_handleBatchExport, '批量导出'),
  formatAsMarkdown,
  getFileIcon,
};
