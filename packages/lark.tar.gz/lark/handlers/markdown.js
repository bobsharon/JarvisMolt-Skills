/**
 * Markdown 双向转换处理器
 * 飞书文档 Block 结构 ↔ 标准 Markdown
 * API: docx:document scope (已有)
 */

const fs = require('fs');
const path = require('path');
const os = require('os');
const { withAuth } = require('../lib/with-auth');

// ============== 飞书 Block → Markdown ==============

const BLOCK_TYPE = {
  1: 'page',
  2: 'text',
  3: 'heading1',
  4: 'heading2',
  5: 'heading3',
  6: 'heading4',
  7: 'heading5',
  8: 'heading6',
  9: 'heading7',
  10: 'heading8',
  11: 'heading9',
  12: 'bullet',
  13: 'ordered',
  14: 'code',
  15: 'quote',
  16: 'todo',
  17: 'divider',
  18: 'image',
  19: 'table',
  20: 'table_cell',
  22: 'callout',
  27: 'grid',
  28: 'grid_column',
};

/**
 * 将飞书文本元素数组转为 Markdown 内联文本
 */
function elementsToMarkdown(elements) {
  if (!elements || !Array.isArray(elements)) return '';

  return elements.map(el => {
    if (el.text_run) {
      let text = el.text_run.content || '';
      const style = el.text_run.text_element_style || {};
      if (style.bold) text = `**${text}**`;
      if (style.italic) text = `*${text}*`;
      if (style.strikethrough) text = `~~${text}~~`;
      if (style.inline_code) text = `\`${text}\``;
      if (style.link && style.link.url) {
        text = `[${text}](${style.link.url})`;
      }
      return text;
    }
    if (el.mention_user) {
      return `@${el.mention_user.user_name || el.mention_user.user_id || '用户'}`;
    }
    if (el.equation) {
      return `$${el.equation.content || ''}$`;
    }
    return '';
  }).join('');
}

/**
 * 递归将飞书 Block 树转为 Markdown
 */
function blockToMarkdown(block, allBlocks, depth = 0) {
  if (!block) return '';

  const type = block.block_type;
  const lines = [];

  switch (type) {
    case 1: // page — 跳过，处理子节点
      break;

    case 2: { // text
      const text = elementsToMarkdown(block.text && block.text.elements);
      lines.push(text);
      break;
    }

    case 3: case 4: case 5: case 6: case 7: case 8: case 9: case 10: case 11: {
      // heading1-9
      const level = type - 2;
      const hKey = `heading${level}`;
      const heading = block[hKey] || block.heading;
      const text = elementsToMarkdown(heading && heading.elements);
      lines.push(`${'#'.repeat(Math.min(level, 6))} ${text}`);
      break;
    }

    case 12: { // bullet list
      const text = elementsToMarkdown(block.bullet && block.bullet.elements);
      const indent = '  '.repeat(depth);
      lines.push(`${indent}- ${text}`);
      break;
    }

    case 13: { // ordered list
      const text = elementsToMarkdown(block.ordered && block.ordered.elements);
      const indent = '  '.repeat(depth);
      lines.push(`${indent}1. ${text}`);
      break;
    }

    case 14: { // code block
      const code = block.code || {};
      const lang = code.language ? code.language.toLowerCase() : '';
      const text = elementsToMarkdown(code.elements);
      lines.push(`\`\`\`${lang}`);
      lines.push(text);
      lines.push('```');
      break;
    }

    case 15: { // quote
      const text = elementsToMarkdown(block.quote && block.quote.elements);
      lines.push(`> ${text}`);
      break;
    }

    case 16: { // todo
      const todo = block.todo || {};
      const checked = todo.done ? 'x' : ' ';
      const text = elementsToMarkdown(todo.elements);
      lines.push(`- [${checked}] ${text}`);
      break;
    }

    case 17: // divider
      lines.push('---');
      break;

    case 18: { // image
      const image = block.image || {};
      const token = image.token || '';
      const alt = image.alt || '图片';
      lines.push(`![${alt}](feishu://image/${token})`);
      break;
    }

    case 19: { // table
      // 表格需要特殊处理：收集所有 table_cell 子块
      const tableBlock = block.table || {};
      const rows = tableBlock.rows || 0;
      const cols = tableBlock.columns || 0;
      if (rows > 0 && cols > 0 && block.children) {
        const cells = block.children.map(childId => allBlocks[childId]).filter(Boolean);
        const grid = [];
        for (let r = 0; r < rows; r++) {
          const row = [];
          for (let c = 0; c < cols; c++) {
            const cell = cells[r * cols + c];
            if (cell && cell.children) {
              const cellContent = cell.children
                .map(id => allBlocks[id])
                .filter(Boolean)
                .map(b => blockToMarkdown(b, allBlocks, 0))
                .join(' ');
              row.push(cellContent.trim());
            } else {
              row.push('');
            }
          }
          grid.push(row);
        }
        // 输出 GFM 表格
        if (grid.length > 0) {
          lines.push('| ' + grid[0].join(' | ') + ' |');
          lines.push('| ' + grid[0].map(() => '---').join(' | ') + ' |');
          for (let r = 1; r < grid.length; r++) {
            lines.push('| ' + grid[r].join(' | ') + ' |');
          }
        }
      }
      break;
    }

    case 22: { // callout
      const callout = block.callout || {};
      const text = elementsToMarkdown(callout.elements);
      lines.push(`> **Note:** ${text}`);
      break;
    }

    default: {
      // 尝试通用文本提取
      const generic = block.text || block[`heading${type - 2}`];
      if (generic && generic.elements) {
        lines.push(elementsToMarkdown(generic.elements));
      }
    }
  }

  // 递归处理子块（非表格）
  if (block.children && type !== 19 && type !== 20) {
    for (const childId of block.children) {
      const child = allBlocks[childId];
      if (child) {
        const childDepth = (type === 12 || type === 13) ? depth + 1 : 0;
        lines.push(blockToMarkdown(child, allBlocks, childDepth));
      }
    }
  }

  return lines.join('\n');
}

/**
 * 将完整的飞书文档 Block 结构转为 Markdown
 */
function blocksToMarkdown(documentBody, title) {
  if (!documentBody || !documentBody.blocks) return `# ${title || '无标题'}\n`;

  const blocks = documentBody.blocks;
  // 建立 block_id → block 的映射
  const blockMap = {};
  for (const block of blocks) {
    blockMap[block.block_id] = block;
  }

  const lines = [];
  if (title) lines.push(`# ${title}\n`);

  // 从根节点开始遍历
  const rootBlock = blocks.find(b => b.block_type === 1) || blocks[0];
  if (rootBlock && rootBlock.children) {
    for (const childId of rootBlock.children) {
      const child = blockMap[childId];
      if (child) {
        lines.push(blockToMarkdown(child, blockMap, 0));
        lines.push(''); // 段落间空行
      }
    }
  } else {
    // 无树结构，按顺序处理
    for (const block of blocks) {
      if (block.block_type !== 1) {
        lines.push(blockToMarkdown(block, blockMap, 0));
        lines.push('');
      }
    }
  }

  return lines.join('\n').replace(/\n{3,}/g, '\n\n').trim() + '\n';
}
// ============== Markdown → 飞书 Block ==============

/**
 * 简易 Markdown 解析器 → 飞书 Block 结构
 * 支持：标题、段落、列表、代码块、引用、分割线、表格、图片
 */
function markdownToBlocks(mdContent) {
  const lines = mdContent.split('\n');
  const blocks = [];
  let i = 0;

  while (i < lines.length) {
    const line = lines[i];

    // 空行跳过
    if (line.trim() === '') { i++; continue; }

    // 代码块
    if (line.trim().startsWith('```')) {
      const lang = line.trim().slice(3).trim();
      const codeLines = [];
      i++;
      while (i < lines.length && !lines[i].trim().startsWith('```')) {
        codeLines.push(lines[i]);
        i++;
      }
      i++; // skip closing ```
      blocks.push({
        block_type: 14,
        code: {
          language: lang || 'plain_text',
          elements: [{ text_run: { content: codeLines.join('\n') } }]
        }
      });
      continue;
    }

    // 标题
    const headingMatch = line.match(/^(#{1,6})\s+(.+)/);
    if (headingMatch) {
      const level = headingMatch[1].length;
      blocks.push({
        block_type: level + 2,
        [`heading${level}`]: {
          elements: [{ text_run: { content: headingMatch[2] } }]
        }
      });
      i++; continue;
    }

    // 分割线
    if (/^(-{3,}|_{3,}|\*{3,})$/.test(line.trim())) {
      blocks.push({ block_type: 17 });
      i++; continue;
    }

    // 引用
    if (line.trim().startsWith('> ')) {
      blocks.push({
        block_type: 15,
        quote: {
          elements: [{ text_run: { content: line.trim().slice(2) } }]
        }
      });
      i++; continue;
    }

    // 无序列表
    if (/^\s*[-*+]\s/.test(line)) {
      const text = line.replace(/^\s*[-*+]\s+/, '');
      // 检查是否是 todo
      const todoMatch = text.match(/^\[([x ])\]\s*(.*)/i);
      if (todoMatch) {
        blocks.push({
          block_type: 16,
          todo: {
            done: todoMatch[1].toLowerCase() === 'x',
            elements: [{ text_run: { content: todoMatch[2] } }]
          }
        });
      } else {
        blocks.push({
          block_type: 12,
          bullet: {
            elements: [{ text_run: { content: text } }]
          }
        });
      }
      i++; continue;
    }

    // 有序列表
    if (/^\s*\d+\.\s/.test(line)) {
      const text = line.replace(/^\s*\d+\.\s+/, '');
      blocks.push({
        block_type: 13,
        ordered: {
          elements: [{ text_run: { content: text } }]
        }
      });
      i++; continue;
    }

    // GFM 表格
    if (line.includes('|') && i + 1 < lines.length && /^\s*\|?\s*[-:]+/.test(lines[i + 1])) {
      const headerCells = line.split('|').map(c => c.trim()).filter(Boolean);
      i += 2; // skip header + separator
      const rows = [headerCells];
      while (i < lines.length && lines[i].includes('|')) {
        const cells = lines[i].split('|').map(c => c.trim()).filter(Boolean);
        rows.push(cells);
        i++;
      }
      // 构造表格 block（简化版）
      blocks.push({
        block_type: 19,
        table: {
          rows: rows.length,
          columns: headerCells.length,
          cells: rows // 简化存储
        }
      });
      continue;
    }

    // 图片
    const imgMatch = line.match(/!\[([^\]]*)\]\(([^)]+)\)/);
    if (imgMatch) {
      blocks.push({
        block_type: 18,
        image: { alt: imgMatch[1], url: imgMatch[2] }
      });
      i++; continue;
    }

    // 普通段落
    blocks.push({
      block_type: 2,
      text: {
        elements: [{ text_run: { content: line } }]
      }
    });
    i++;
  }

  return blocks;
}
// ============== 命令处理器 ==============

/**
 * 导出飞书文档为 Markdown
 */
async function _handleExport(docName, savePath, deps) {
  const { api, logger } = deps;

  // 搜索文档
  const searchResult = await api.searchDocuments(docName, { pageSize: 5 });
  const files = searchResult.files || [];

  if (files.length === 0) {
    return { success: false, response: `未找到名为"${docName}"的文档。` };
  }

  const doc = files.find(f =>
    f.name.toLowerCase().includes(docName.toLowerCase())
  ) || files[0];

  // 尝试获取 Block 结构
  let markdown;
  try {
    const blocksData = await api.request(
      `/docx/v1/documents/${doc.token}/blocks?page_size=500`
    );
    const documentBody = { blocks: (blocksData && blocksData.items) || [] };
    markdown = blocksToMarkdown(documentBody, doc.name);
  } catch (e) {
    // 降级：使用纯文本内容
    logger.warn('获取 Block 结构失败，使用纯文本降级', { error: e.message });
    const docInfo = await api.getDocumentContent(doc.token, doc.type);
    markdown = `# ${doc.name}\n\n${docInfo.content || ''}`;
  }

  // 保存文件
  const targetPath = savePath ||
    path.join(os.homedir(), 'Downloads', `${doc.name.replace(/[/\\?%*:|"<>]/g, '_')}.md`);

  const dir = path.dirname(targetPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  fs.writeFileSync(targetPath, markdown, 'utf8');

  let response = `✅ 已将《${doc.name}》导出为 Markdown\n\n`;
  response += `📄 保存到：${targetPath}\n`;
  response += `📊 大小：${Buffer.byteLength(markdown, 'utf8')} bytes\n`;

  // 显示预览（前 500 字符）
  const preview = markdown.substring(0, 500);
  response += `\n--- 预览 ---\n${preview}`;
  if (markdown.length > 500) response += '\n...';

  logger.info('Markdown 导出', { doc: doc.name, path: targetPath });
  return { success: true, response, path: targetPath };
}

/**
 * 导入 Markdown 到飞书文档
 */
async function _handleImport(filePath, docName, deps) {
  const { api, logger } = deps;

  // 读取 Markdown 文件
  const resolvedPath = filePath.startsWith('~')
    ? path.join(os.homedir(), filePath.slice(1))
    : path.resolve(filePath);

  if (!fs.existsSync(resolvedPath)) {
    return { success: false, response: `文件不存在：${resolvedPath}` };
  }

  const mdContent = fs.readFileSync(resolvedPath, 'utf8');
  const blocks = markdownToBlocks(mdContent);

  // 创建新文档
  const createData = await api.request('/docx/v1/documents', {
    method: 'POST',
    body: { title: docName }
  });

  const docToken = createData && createData.document && createData.document.document_id;
  if (!docToken) {
    return { success: false, response: '创建文档失败：未获取到文档 ID' };
  }

  // 逐个添加 Block（飞书 API 限制）
  let addedCount = 0;
  for (const block of blocks) {
    try {
      await api.request(
        `/docx/v1/documents/${docToken}/blocks/batch_create`,
        { method: 'POST', body: { blocks: [block] } }
      );
      addedCount++;
    } catch (e) {
      logger.warn('添加 Block 失败', { type: block.block_type, error: e.message });
    }
    // 避免限流
    await new Promise(r => setTimeout(r, 100));
  }

  let response = `✅ 已将 ${path.basename(resolvedPath)} 导入飞书文档《${docName}》\n\n`;
  response += `📊 统计：\n`;
  response += `  - 解析了 ${blocks.length} 个内容块\n`;
  response += `  - 成功写入 ${addedCount} 个\n`;

  const blockTypes = {};
  blocks.forEach(b => {
    const name = BLOCK_TYPE[b.block_type] || `type_${b.block_type}`;
    blockTypes[name] = (blockTypes[name] || 0) + 1;
  });
  for (const [type, count] of Object.entries(blockTypes)) {
    response += `  - ${type}: ${count} 个\n`;
  }

  logger.info('Markdown 导入', { file: resolvedPath, doc: docName, blocks: addedCount });
  return { success: true, response };
}

/**
 * 在终端预览飞书文档的 Markdown 版本
 */
async function _handlePreview(docName, deps) {
  const { api, logger } = deps;

  const searchResult = await api.searchDocuments(docName, { pageSize: 5 });
  const files = searchResult.files || [];

  if (files.length === 0) {
    return { success: false, response: `未找到名为"${docName}"的文档。` };
  }

  const doc = files.find(f =>
    f.name.toLowerCase().includes(docName.toLowerCase())
  ) || files[0];

  let markdown;
  try {
    const blocksData = await api.request(
      `/docx/v1/documents/${doc.token}/blocks?page_size=500`
    );
    const documentBody = { blocks: (blocksData && blocksData.items) || [] };
    markdown = blocksToMarkdown(documentBody, doc.name);
  } catch (e) {
    const docInfo = await api.getDocumentContent(doc.token, doc.type);
    markdown = `# ${doc.name}\n\n${docInfo.content || ''}`;
  }

  logger.info('Markdown 预览', { doc: doc.name });
  return { success: true, response: markdown };
}

module.exports = {
  handleExport: withAuth(_handleExport, 'Markdown 导出'),
  handleImport: withAuth(_handleImport, 'Markdown 导入'),
  handlePreview: withAuth(_handlePreview, 'Markdown 预览'),
  blocksToMarkdown,
  markdownToBlocks,
  elementsToMarkdown
};
