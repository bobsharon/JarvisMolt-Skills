/**
 * 审批流程查询处理器
 * 查询我的审批列表、审批详情
 * API: approval:approval:readonly scope
 *
 * FeishuAPI.request(endpoint, options) 返回已解包的 data
 */

const { withAuth } = require('../lib/with-auth');

const STATUS_MAP = {
  PENDING: '⏳ 待审批',
  APPROVED: '✅ 已通过',
  REJECTED: '❌ 已拒绝',
  CANCELED: '🚫 已撤回',
  DELETED: '🗑️ 已删除',
};

function formatTime(ts) {
  if (!ts) return '';
  const ms = typeof ts === 'string' ? parseInt(ts) : ts;
  return new Date(ms > 1e12 ? ms : ms * 1000).toLocaleDateString();
}

/**
 * 查询我的审批列表
 * @param {string|null} statusFilter - 状态筛选 (待审/已审/全部)
 */
async function _handleList(statusFilter, deps) {
  const { api, logger } = deps;

  const data = await api.request('/approval/v4/instances/query', {
    method: 'POST',
    body: {
      user_id_type: 'open_id',
      page_size: 20
    }
  });

  let instances = (data && data.instance_list) || [];

  // 状态筛选
  if (statusFilter === '待审') {
    instances = instances.filter(i => i.status === 'PENDING');
  } else if (statusFilter === '已审') {
    instances = instances.filter(i => i.status === 'APPROVED' || i.status === 'REJECTED');
  }

  if (instances.length === 0) {
    const filterText = statusFilter ? `（${statusFilter}）` : '';
    return { success: true, response: `📋 没有${filterText}审批记录。` };
  }

  const filterText = statusFilter ? `（${statusFilter}）` : '';
  let response = `📋 我的审批${filterText}（${instances.length} 条）：\n\n`;
  instances.slice(0, 15).forEach((inst, idx) => {
    const status = STATUS_MAP[inst.status] || inst.status;
    response += `${idx + 1}. ${status} ${inst.approval_name || '审批'}\n`;
    if (inst.start_time) response += `   提交于 ${formatTime(inst.start_time)}\n`;
    if (inst.end_time) response += `   完成于 ${formatTime(inst.end_time)}\n`;
  });

  if (instances.length > 15) {
    response += `\n... 还有 ${instances.length - 15} 条记录`;
  }

  logger.info('审批列表', { filter: statusFilter, count: instances.length });
  return { success: true, response };
}

/**
 * 审批详情
 * @param {string} instanceId - 审批实例 ID
 */
async function _handleDetail(instanceId, deps) {
  const { api, logger } = deps;

  const data = await api.request(`/approval/v4/instances/${instanceId}`);

  if (!data) {
    return { success: false, response: `未找到审批编号"${instanceId}"。` };
  }

  const status = STATUS_MAP[data.status] || data.status;
  let response = `📋 审批详情\n${'='.repeat(20)}\n\n`;
  response += `状态：${status}\n`;
  if (data.approval_name) response += `类型：${data.approval_name}\n`;
  if (data.start_time) response += `提交时间：${formatTime(data.start_time)}\n`;
  if (data.end_time) response += `完成时间：${formatTime(data.end_time)}\n`;
  if (data.user_id) response += `申请人 ID：${data.user_id}\n`;

  // 审批节点
  const timeline = data.timeline || [];
  if (timeline.length > 0) {
    response += '\n审批流程：\n';
    timeline.forEach((node, idx) => {
      const nodeStatus = STATUS_MAP[node.status] || node.status || '';
      response += `  ${idx + 1}. ${nodeStatus} ${node.user_name || node.user_id || ''}\n`;
      if (node.comment) response += `     💬 ${node.comment}\n`;
    });
  }

  logger.info('审批详情', { instanceId });
  return { success: true, response };
}

module.exports = {
  handleList: withAuth(_handleList, '获取审批列表'),
  handleDetail: withAuth(_handleDetail, '获取审批详情'),
};
