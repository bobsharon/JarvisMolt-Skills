/**
 * 跨文档分析处理器
 * 搜索多文档聚合分析、双文档对比
 * API: drive:drive scope
 *
 * FeishuAPI.request(endpoint, options) 返回已解包的 data
 */

const { withAuth } = require('../lib/with-auth');

/**
 * 跨文档聚合分析
 * 搜索 scope 关键词匹配的文档，读取内容后用 LLM 聚合回答 question
 */
async function _handleAnalyze(question, scope, deps) {
  const { api, cache, logger, getSummaryService, context } = deps;

  console.log(`🔍 正在搜索"${scope}"相关文档...`);

  // 1. 搜索匹配文档
  const cacheKey = `crossdoc:search:${scope}`;
  let files = cache.get(cacheKey);

  if (!files) {
    const result = await api.searchDocuments(scope, { pageSize: 20 });
    files = (result && result.files) || [];
    cache.set(cacheKey, files);
  }

  if (files.length === 0) {
    return { success: false, response: `未找到与"${scope}"相关的文档。` };
  }

  console.log(`📄 找到 ${files.length} 个相关文档，正在读取内容...`);

  // 2. 读取文档内容（最多 5 篇）
  const contents = [];
  for (const file of files.slice(0, 5)) {
    try {
      const docInfo = await api.getDocumentContent(file.token, file.type);
      if (docInfo && docInfo.content) {
        contents.push({
          title: file.name,
          content: docInfo.content.substring(0, 3000),
          url: file.url
        });
      }
    } catch (e) {
      logger.warn('读取文档失败', { token: file.token, error: e.message });
    }
  }

  if (contents.length === 0) {
    return {
      success: false,
      response: `搜索到 ${files.length} 个文档但无法读取内容。\n\n相关文档：\n${files.slice(0, 10).map((f, i) => `${i + 1}. ${f.name}`).join('\n')}`
    };
  }

  // 3. LLM 聚合分析
  const service = getSummaryService(context);
  const combinedContent = contents.map(c =>
    `【${c.title}】\n${c.content}`
  ).join('\n\n---\n\n');

  const prompt = `你是一个跨文档分析助手。基于以下 ${contents.length} 个飞书文档的内容，回答用户的问题。请提取关键数据，分条列出各文档的要点，最后给出综合结论。\n\n问题：${question}\n\n文档内容：\n${combinedContent}`;

  const result = await service.summarize(prompt, {
    maxLength: 1000,
    style: 'detailed'
  });

  let response = `📊 跨文档分析\n${'='.repeat(20)}\n\n`;
  response += `❓ ${question}\n`;
  response += `📂 范围：${scope}（搜索到 ${files.length} 个文档，分析了 ${contents.length} 个）\n\n`;
  response += result.summary + '\n\n';
  response += '---\n📖 分析来源：\n';
  contents.forEach((c, idx) => {
    response += `${idx + 1}. ${c.title}`;
    if (c.url) response += ` — ${c.url}`;
    response += '\n';
  });

  logger.info('跨文档分析', { question, scope, found: files.length, analyzed: contents.length, provider: result.provider });
  return { success: true, response };
}

/**
 * 双文档对比
 * 读取两个指定文档，用 LLM 进行对比分析
 */
async function _handleCompare(docName1, docName2, deps) {
  const { api, logger, getSummaryService, context } = deps;

  console.log(`🔍 正在查找文档："${docName1}" 和 "${docName2}"...`);
  // 1. 搜索两个文档
  const [result1, result2] = await Promise.all([
    api.searchDocuments(docName1, { pageSize: 5 }),
    api.searchDocuments(docName2, { pageSize: 5 })
  ]);

  const file1 = (result1.files || [])[0];
  const file2 = (result2.files || [])[0];

  if (!file1) return { success: false, response: `未找到文档"${docName1}"。` };
  if (!file2) return { success: false, response: `未找到文档"${docName2}"。` };

  console.log('📄 正在读取文档内容...');

  // 2. 读取两个文档内容
  const [doc1, doc2] = await Promise.all([
    api.getDocumentContent(file1.token, file1.type),
    api.getDocumentContent(file2.token, file2.type)
  ]);

  if (!doc1 || !doc1.content) return { success: false, response: `无法读取文档"${file1.name}"的内容。` };
  if (!doc2 || !doc2.content) return { success: false, response: `无法读取文档"${file2.name}"的内容。` };

  // 3. LLM 对比分析
  const service = getSummaryService(context);
  const prompt = `请对比以下两个飞书文档，从结构、内容、数据等维度进行详细对比分析，列出异同点和关键差异。\n\n【文档一：${file1.name}】\n${doc1.content.substring(0, 4000)}\n\n【文档二：${file2.name}】\n${doc2.content.substring(0, 4000)}`;

  const result = await service.summarize(prompt, {
    maxLength: 1000,
    style: 'detailed'
  });

  let response = `📊 文档对比分析\n${'='.repeat(20)}\n\n`;
  response += `📄 文档一：${file1.name}`;
  if (file1.url) response += ` — ${file1.url}`;
  response += '\n';
  response += `📄 文档二：${file2.name}`;
  if (file2.url) response += ` — ${file2.url}`;
  response += '\n\n';
  response += result.summary;

  logger.info('文档对比', { doc1: file1.name, doc2: file2.name, provider: result.provider });
  return { success: true, response };
}

module.exports = {
  handleAnalyze: withAuth(_handleAnalyze, '跨文档分析'),
  handleCompare: withAuth(_handleCompare, '文档对比')
};
