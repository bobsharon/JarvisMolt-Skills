/**
 * 日程/会议智能处理器
 * 今日日程、本周日程、会议准备、空闲时间查询
 * API: calendar:calendar:readonly scope
 *
 * FeishuAPI.request(endpoint, options) 返回已解包的 data
 * FeishuAPI.getCalendars() / getCalendarEvents(calendarId, options)
 */

const { withAuth } = require('../lib/with-auth');

function formatEventTime(timestamp) {
  if (!timestamp) return '';
  const d = new Date(parseInt(timestamp) * 1000);
  return `${d.getMonth() + 1}/${d.getDate()} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}

function formatTimeOnly(timestamp) {
  if (!timestamp) return '';
  const d = new Date(parseInt(timestamp) * 1000);
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}

/**
 * 获取主日历 ID
 */
async function getPrimaryCalendarId(api) {
  const data = await api.getCalendars();
  const calendars = (data && data.calendar_list) || [];
  const primary = calendars.find(c => c.type === 'primary') || calendars[0];
  if (!primary) throw new Error('未找到日历，请确认已开启日历权限');
  return primary.calendar_id;
}

/**
 * 获取时间范围内的事件
 */
async function fetchEvents(api, calendarId, startTime, endTime) {
  const data = await api.getCalendarEvents(calendarId, { startTime, endTime });
  return (data && data.items) || [];
}

/**
 * 今日日程
 */
async function _handleToday(deps) {
  const { api, logger } = deps;
  const calendarId = await getPrimaryCalendarId(api);

  const now = new Date();
  const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const endOfDay = new Date(startOfDay.getTime() + 24 * 60 * 60 * 1000);

  const events = await fetchEvents(api, calendarId,
    Math.floor(startOfDay.getTime() / 1000),
    Math.floor(endOfDay.getTime() / 1000)
  );

  if (events.length === 0) {
    return { success: true, response: '📅 今天没有日程安排。' };
  }

  let response = `📅 今日日程（${events.length} 个）：\n\n`;
  events.forEach((ev, idx) => {
    const start = formatTimeOnly(ev.start_time && ev.start_time.timestamp);
    const end = formatTimeOnly(ev.end_time && ev.end_time.timestamp);
    response += `${idx + 1}. ${start}-${end} ${ev.summary || '(无标题)'}\n`;
    if (ev.location && ev.location.name) response += `   📍 ${ev.location.name}\n`;
    if (ev.description) response += `   ${ev.description.substring(0, 80)}\n`;
  });

  logger.info('今日日程', { count: events.length });
  return { success: true, response };
}

/**
 * 本周日程
 */
async function _handleWeek(deps) {
  const { api, logger } = deps;
  const calendarId = await getPrimaryCalendarId(api);

  const now = new Date();
  const dayOfWeek = now.getDay() || 7; // 周日=7
  const startOfWeek = new Date(now.getFullYear(), now.getMonth(), now.getDate() - dayOfWeek + 1);
  const endOfWeek = new Date(startOfWeek.getTime() + 7 * 24 * 60 * 60 * 1000);

  const events = await fetchEvents(api, calendarId,
    Math.floor(startOfWeek.getTime() / 1000),
    Math.floor(endOfWeek.getTime() / 1000)
  );

  if (events.length === 0) {
    return { success: true, response: '📅 本周没有日程安排。' };
  }

  let response = `📅 本周日程（${events.length} 个）：\n\n`;
  events.forEach((ev, idx) => {
    const start = formatEventTime(ev.start_time && ev.start_time.timestamp);
    const end = formatTimeOnly(ev.end_time && ev.end_time.timestamp);
    response += `${idx + 1}. ${start}-${end} ${ev.summary || '(无标题)'}\n`;
    if (ev.location && ev.location.name) response += `   📍 ${ev.location.name}\n`;
  });

  logger.info('本周日程', { count: events.length });
  return { success: true, response };
}

/**
 * 会议准备 — 查找即将到来的会议并汇总相关文档
 */
async function _handleMeetingPrep(meetingName, deps) {
  const { api, cache, logger } = deps;
  const calendarId = await getPrimaryCalendarId(api);

  // 搜索未来 7 天的事件
  const now = Math.floor(Date.now() / 1000);
  const weekLater = now + 7 * 24 * 60 * 60;
  const events = await fetchEvents(api, calendarId, now, weekLater);

  const matched = events.filter(ev =>
    ev.summary && ev.summary.toLowerCase().includes(meetingName.toLowerCase())
  );

  if (matched.length === 0) {
    return { success: false, response: `未找到名为"${meetingName}"的会议。` };
  }

  const ev = matched[0];
  let response = `📋 会议准备：${ev.summary}\n${'='.repeat(25)}\n\n`;
  const start = formatEventTime(ev.start_time && ev.start_time.timestamp);
  const end = formatTimeOnly(ev.end_time && ev.end_time.timestamp);
  response += `⏰ 时间：${start}-${end}\n`;
  if (ev.location && ev.location.name) response += `📍 地点：${ev.location.name}\n`;
  if (ev.description) response += `📝 描述：${ev.description}\n`;

  // 搜索相关文档
  const result = await api.searchDocuments(meetingName, { pageSize: 5 });
  const files = (result && result.files) || [];
  if (files.length > 0) {
    response += `\n📂 相关文档（${files.length} 个）：\n`;
    files.forEach((f, idx) => {
      response += `${idx + 1}. ${f.name}`;
      if (f.url) response += ` — ${f.url}`;
      response += '\n';
    });
  }

  logger.info('会议准备', { meeting: ev.summary, relatedDocs: files.length });
  return { success: true, response };
}

/**
 * 指定日期日程
 */
async function _handleDate(dateStr, deps) {
  const { api, logger } = deps;
  const calendarId = await getPrimaryCalendarId(api);

  const parsed = new Date(dateStr);
  if (isNaN(parsed.getTime())) {
    return { success: false, response: `无法解析日期"${dateStr}"，请使用 YYYY-MM-DD 格式。` };
  }

  const startOfDay = new Date(parsed.getFullYear(), parsed.getMonth(), parsed.getDate());
  const endOfDay = new Date(startOfDay.getTime() + 24 * 60 * 60 * 1000);

  const events = await fetchEvents(api, calendarId,
    Math.floor(startOfDay.getTime() / 1000),
    Math.floor(endOfDay.getTime() / 1000)
  );

  const label = `${parsed.getMonth() + 1}/${parsed.getDate()}`;
  if (events.length === 0) {
    return { success: true, response: `📅 ${label} 没有日程安排。` };
  }

  let response = `📅 ${label} 日程（${events.length} 个）：\n\n`;
  events.forEach((ev, idx) => {
    const start = formatTimeOnly(ev.start_time && ev.start_time.timestamp);
    const end = formatTimeOnly(ev.end_time && ev.end_time.timestamp);
    response += `${idx + 1}. ${start}-${end} ${ev.summary || '(无标题)'}\n`;
    if (ev.location && ev.location.name) response += `   📍 ${ev.location.name}\n`;
    if (ev.description) response += `   ${ev.description.substring(0, 80)}\n`;
  });

  logger.info('指定日期日程', { date: dateStr, count: events.length });
  return { success: true, response };
}

module.exports = {
  handleToday: withAuth(_handleToday, '获取今日日程'),
  handleWeek: withAuth(_handleWeek, '获取本周日程'),
  handleMeetingPrep: withAuth(_handleMeetingPrep, '会议准备'),
  handleDate: withAuth(_handleDate, '获取指定日期日程'),
};
