/**
 * OAuth 授权流程处理器
 * handleAuth, handleAuthToken, handleAuthCode, handleLogout, handleStatus
 * 从 agent.js 提取
 */

const fs = require('fs');
const path = require('path');
const os = require('os');
const { execSync } = require('child_process');
const { FeishuAPI, FeishuAuth } = require('../feishu-api');
const { generateRandomString, formatTime } = require('../utils');
const { loadAppConfig, loadTokens, saveTokens, clearTokens, logger } = require('../lib/auth-manager');

async function handleAuth() {
  const config = loadAppConfig();
  if (!config) {
    return {
      success: true,
      response: `🔐 飞书授权配置

飞书技能需要你提供自建应用的凭据，用于以你的身份访问飞书文档、表格、日历等数据。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📝 **快速配置（推荐，3 分钟）**

1. 打开飞书开放平台：https://open.feishu.cn/
2. 创建「企业自建应用」，获取 App ID 和 App Secret
3. 在应用的「权限管理」中申请以下权限并发布应用：
   • docx:document（文档读写）
   • drive:drive（云盘访问）
   • wiki:wiki:readonly（知识库）
   • bitable:app（多维表格）
   • calendar:calendar:readonly（日历）
   • contact:user.base:readonly（用户信息）
4. 在「安全设置」中添加重定向 URL：
   https://oauth-callback-bchxphkcet.cn-shanghai.fcapp.run/callback

然后回来告诉我凭据：
\`飞书配置 App ID: cli_你的appid Secret: 你的secret\`

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🤔 **为什么需要自建应用？**
• 你的数据完全私密，不经过任何第三方服务器
• 应用完全属于你，不依赖 JarvisMolt 服务
• 使用你自己的飞书账号权限，访问你有权限的文档

💡 如果觉得麻烦，也可以输入"飞书购买服务"获取人工协助配置`
    };
  }

  const auth = new FeishuAuth(config.appId, config.appSecret);
  const state = generateRandomString(32);

  const callbackUrl = process.env.FEISHU_CALLBACK_URL || config.redirectUri;
  const authUrl = auth.generateAuthUrl(callbackUrl, state);

  // 保存 state
  const statePath = path.join(os.homedir(), '.openclaw', 'skills', 'lark', 'oauth_state.json');
  const stateDir = path.dirname(statePath);
  if (!fs.existsSync(stateDir)) {
    fs.mkdirSync(stateDir, { recursive: true });
  }

  fs.writeFileSync(statePath, JSON.stringify({
    state,
    timestamp: Date.now(),
    expiresAt: Date.now() + 5 * 60 * 1000
  }));

  logger.info('生成授权URL', { state, callbackUrl });
  console.log('\n🌐 正在打开浏览器进行授权...\n');

  try {
    const platform = process.platform;
    if (platform === 'darwin') {
      execSync(`open "${authUrl}"`);
    } else if (platform === 'win32') {
      execSync(`start "" "${authUrl}"`);
    } else {
      execSync(`xdg-open "${authUrl}"`);
    }
    console.log('✅ 浏览器已打开，请在浏览器中完成授权\n');
  } catch (e) {
    console.log('⚠️ 无法自动打开浏览器，请手动访问：\n');
    console.log(authUrl + '\n');
  }

  if (callbackUrl && !callbackUrl.includes('localhost')) {
    return pollForAuthCode(config, state, callbackUrl);
  } else {
    return {
      success: true,
      response: `请在浏览器中完成飞书授权绑定：\n\n${authUrl}\n\n授权完成后，从浏览器页面复制token。\n然后执行：飞书授权token <token>`
    };
  }
}

async function pollForAuthCode(config, expectedState, callbackUrl) {
  const pollUrl = new URL('/poll', callbackUrl).href + '?state=' + expectedState;
  const maxAttempts = 150;
  const interval = 2000;

  const https = require('https');
  const http = require('http');

  const sleep = (ms) => new Promise(r => setTimeout(r, ms));

  const fetchJson = (url) => new Promise((resolve, reject) => {
    const client = url.startsWith('https') ? https : http;
    client.get(url, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          resolve({ status: res.statusCode, body: JSON.parse(data) });
        } catch {
          resolve({ status: res.statusCode, body: data });
        }
      });
    }).on('error', reject);
  });

  for (let i = 1; i <= maxAttempts; i++) {
    await sleep(interval);
    try {
      const res = await fetchJson(pollUrl);
      if (res.status === 200 && res.body.status === 'ready' && res.body.accessToken) {
        console.log('✅ 授权码获取成功\n');
        return await handleAuthToken(res.body.accessToken);
      }
      if (res.status === 410 || res.body.status === 'expired') {
        console.log('⏰ 授权已过期\n');
        break;
      }
      // 202 pending — 继续轮询
      process.stdout.write(`\r⏳ 等待授权完成... (${i}/${maxAttempts})`);
    } catch (e) {
      // 网络错误，继续轮询
    }
  }

  console.log('\n');
  return {
    success: true,
    response: '⏰ 自动授权超时，请手动执行：飞书授权token <token>'
  };
}

async function handleAuthToken(token) {
  const config = loadAppConfig();
  if (!config) {
    return { success: false, response: '未找到应用配置，请先设置环境变量或创建 config/app.json' };
  }

  const callbackUrl = process.env.FEISHU_CALLBACK_URL || config.redirectUri;
  const callbackUrlObj = new URL(callbackUrl);
  const tokenUrl = `${callbackUrlObj.protocol}//${callbackUrlObj.host}/token?token=${token}`;

  try {
    console.log('\n⏳ 正在获取授权码...\n');

    const https = require('https');
    const http = require('http');
    const client = tokenUrl.startsWith('https') ? https : http;

    const response = await new Promise((resolve, reject) => {
      client.get(tokenUrl, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          if (res.statusCode === 200) {
            resolve(JSON.parse(data));
          } else {
            reject(new Error(`HTTP ${res.statusCode}: ${data}`));
          }
        });
      }).on('error', reject);
    });

    if (!response.success || !response.code) {
      return { success: false, response: '❌ 获取授权码失败：Token无效或已过期' };
    }

    const code = response.code;
    console.log('✅ 授权码获取成功\n');

    // 验证 state
    const statePath = path.join(os.homedir(), '.openclaw', 'skills', 'lark', 'oauth_state.json');
    if (fs.existsSync(statePath)) {
      try {
        const savedState = JSON.parse(fs.readFileSync(statePath, 'utf8'));
        if (Date.now() > savedState.expiresAt) {
          logger.warn('OAuth state 已过期');
          fs.unlinkSync(statePath);
        } else if (response.state && response.state !== savedState.state) {
          logger.warn('OAuth state 不匹配');
          return { success: false, response: '❌ 授权失败：State验证失败，请重新授权' };
        } else if (!response.state) {
          logger.warn('飞书未回传 state，跳过验证');
          fs.unlinkSync(statePath);
        } else {
          fs.unlinkSync(statePath);
          logger.info('OAuth state 验证通过');
        }
      } catch (error) {
        logger.warn('验证 OAuth state 失败', { error: error.message });
      }
    }

    console.log('⏳ 正在交换访问令牌...\n');
    return await _exchangeAndSave(config, code);
  } catch (error) {
    logger.error('授权失败', { error: error.message });
    return {
      success: false,
      response: `❌ 授权失败：${error.message}\n\n可能原因：\n• Token已过期（有效期5分钟）\n• Token已被使用\n• 网络连接失败\n\n请重新执行"飞书授权"。`
    };
  }
}

async function handleAuthCode(code) {
  const config = loadAppConfig();
  if (!config) {
    return { success: false, response: '未找到应用配置，请先设置环境变量或创建 config/app.json' };
  }

  const statePath = path.join(os.homedir(), '.openclaw', 'skills', 'lark', 'oauth_state.json');
  if (fs.existsSync(statePath)) {
    try {
      const savedState = JSON.parse(fs.readFileSync(statePath, 'utf8'));
      if (Date.now() > savedState.expiresAt) {
        logger.warn('OAuth state 已过期');
      } else {
        logger.info('OAuth state 验证通过');
      }
      fs.unlinkSync(statePath);
    } catch (error) {
      logger.warn('验证 OAuth state 失败', { error: error.message });
    }
  }

  try {
    return await _exchangeAndSave(config, code);
  } catch (error) {
    logger.error('授权失败', { error: error.message, code });
    return {
      success: false,
      response: `❌ 授权失败：${error.message}\n\n可能原因：\n• 授权码已过期\n• 授权码已被使用\n• 应用配置错误\n\n请重新执行"飞书授权"获取新的授权码。`
    };
  }
}

async function _exchangeAndSave(config, code) {
  const auth = new FeishuAuth(config.appId, config.appSecret);
  const redirectUri = process.env.FEISHU_CALLBACK_URL || config.redirectUri;
  const tokenData = await auth.exchangeCodeForToken(code, redirectUri);

  const tokens = {
    accessToken: tokenData.access_token,
    refreshToken: tokenData.refresh_token,
    expiresAt: Date.now() + tokenData.expires_in * 1000,
    tokenType: tokenData.token_type
  };
  saveTokens(tokens);

  let userInfo = null;
  try {
    const api = new FeishuAPI(tokens.accessToken);
    userInfo = await api.getUserInfo();
  } catch (error) {
    logger.warn('获取用户信息失败，但授权已成功', { error: error.message });
  }

  const expiresMin = Math.floor(tokenData.expires_in / 60);
  const userLine = userInfo
    ? `用户：${userInfo.name || userInfo.open_id}\n企业：${userInfo.tenant_name || '未知'}\n\n`
    : '';

  return {
    success: true,
    response: `✅ 授权成功！\n\n${userLine}令牌有效期：${expiresMin} 分钟\n存储方式：加密存储（安全）\n\n现在可以使用飞书技能了！\n\n试试：\n• 飞书列出我的文档\n• 飞书搜索文档 产品需求`
  };
}

function handleLogout() {
  if (!loadTokens()) {
    return { success: false, response: '当前未授权。' };
  }
  clearTokens();
  return { success: true, response: '✅ 已取消飞书授权，本地数据已清除。' };
}

function handleStatus() {
  const tokens = loadTokens();
  if (!tokens || !tokens.accessToken) {
    return { success: false, response: '❌ 未授权\n\n请执行"飞书授权"进行绑定。' };
  }

  const now = Date.now();
  const expiresIn = Math.floor((tokens.expiresAt - now) / 1000 / 60);

  if (expiresIn <= 0) {
    return { success: false, response: '❌ 授权已过期\n\n请重新执行"飞书授权"。' };
  }

  return {
    success: true,
    response: `✅ 已授权\n\n令牌有效期：约 ${expiresIn} 分钟\n上次更新：${formatTime(tokens.updatedAt)}\n\n可以使用飞书文档搜索、读取等功能。`
  };
}

// ======================================
// 💰 购买 / 续费
// ======================================

const PAYMENT_API = process.env.JARVISMOLT_PAYMENT_URL || 'https://payment-xxxx.cn-shanghai.fcapp.run';

function makePurchaseRequest(endpoint, data) {
  return new Promise((resolve, reject) => {
    const url = new URL(endpoint, PAYMENT_API);
    const body = JSON.stringify(data);
    const mod = url.protocol === 'https:' ? require('https') : require('http');

    const req = mod.request(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) }
    }, (res) => {
      let chunks = '';
      res.on('data', c => chunks += c);
      res.on('end', () => {
        try { resolve(JSON.parse(chunks)); } catch (e) { reject(new Error('Invalid JSON response')); }
      });
    });
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

function handlePurchase() {
  return {
    success: true,
    response: `📦 选择套餐：

━━ 标准版 ━━
1. 月卡 ¥29.9（30天）
2. 季卡 ¥79.9（90天，省 9.8）
3. 年卡 ¥199（365天，省 159.8）

━━ 旗舰版（含周报/文档对比/审批/团队仪表盘等） ━━
4. 月卡 ¥49.9（30天）
5. 季卡 ¥129.9（90天）
6. 年卡 ¥349.9（365天）

请回复：飞书购买 1~6`
  };
}

async function handlePurchasePlan(planIndex) {
  const plans = [
    'monthly', 'quarterly', 'yearly',
    'enterprise-monthly', 'enterprise-quarterly', 'enterprise-yearly'
  ];
  const planKey = plans[planIndex - 1];
  if (!planKey) {
    return { success: false, response: '无效的套餐编号，请输入 1~6。' };
  }

  // 检测跨 tier 并提示
  const newTier = planIndex <= 3 ? 'standard' : 'enterprise';
  let crossTierWarning = '';
  try {
    const licensePath = path.join(os.homedir(), '.openclaw', 'licenses', 'lark.json');
    if (fs.existsSync(licensePath)) {
      const lic = JSON.parse(fs.readFileSync(licensePath, 'utf8'));
      const currentTier = lic.tier || 'standard';
      const remaining = lic.expiresAt ? Math.floor((lic.expiresAt - Date.now()) / (24*60*60*1000)) : 0;
      if (remaining > 0 && currentTier !== newTier) {
        const direction = newTier === 'enterprise' ? '升级' : '降级';
        crossTierWarning = `\n⚠️ ${direction}提示：您当前为${currentTier === 'enterprise' ? '旗舰' : '标准'}版（剩余 ${remaining} 天）。购买${newTier === 'enterprise' ? '旗舰' : '标准'}版后，有效期从今天开始计算，不叠加剩余天数。\n`;
      }
    }
  } catch (_) {}

  try {
    const resp = await makePurchaseRequest('/create-order', { skill: 'lark', plan: planKey });
    if (!resp.success) {
      return { success: false, response: `创建订单失败：${resp.error || '未知错误'}` };
    }

    console.log(`\n🔗 支付链接: ${resp.payUrl}\n`);

    // 尝试打开浏览器
    try {
      const { execSync } = require('child_process');
      if (process.platform === 'darwin') execSync(`open "${resp.payUrl}"`);
      else if (process.platform === 'win32') execSync(`start "" "${resp.payUrl}"`);
      else execSync(`xdg-open "${resp.payUrl}"`);
    } catch (_) { /* ignore */ }

    // 轮询等待支付
    const orderId = resp.orderId;
    const maxAttempts = 90; // 3 分钟
    const interval = 2000;
    const sleep = ms => new Promise(r => setTimeout(r, ms));

    for (let i = 0; i < maxAttempts; i++) {
      await sleep(interval);
      try {
        const poll = await makePurchaseRequest('/poll-order', { orderId });
        if (poll.status === 'paid' && poll.licenseCode) {
          return {
            success: true,
            response: `✅ 支付成功！${crossTierWarning}

授权码：${poll.licenseCode}

正在自动激活...请稍候。`,
            autoActivate: true,
            licenseCode: poll.licenseCode
          };
        }
        if (poll.status === 'failed') {
          return { success: false, response: '支付失败，请重试或联系客服。' };
        }
      } catch (_) { /* continue polling */ }
    }

    return {
      success: false,
      response: `⏰ 等待支付超时。

如果您已完成支付，请稍后输入「飞书授权状态」查看。
订单号：${orderId}

如需帮助请联系客服。`
    };
  } catch (err) {
    return { success: false, response: `创建订单出错：${err.message}` };
  }
}

function handleRenew() {
  // 续费 = 购买，默认提示当前套餐
  const licensePath = path.join(os.homedir(), '.openclaw', 'licenses', 'lark.json');
  let hint = '';
  if (fs.existsSync(licensePath)) {
    try {
      const lic = JSON.parse(fs.readFileSync(licensePath, 'utf8'));
      const remaining = lic.expiresAt ? Math.floor((lic.expiresAt - Date.now()) / (24*60*60*1000)) : 0;
      const tierLabel = (lic.tier === 'enterprise') ? '旗舰版' : '标准版';
      hint = `\n当前套餐：${tierLabel} ${lic.type || '未知'}，剩余 ${remaining} 天\n`;
    } catch (_) {}
  }

  return {
    success: true,
    response: `🔄 续费飞书技能${hint}
📦 选择续费套餐：

━━ 标准版 ━━
1. 月卡 ¥29.9（30天）
2. 季卡 ¥79.9（90天，省 9.8）
3. 年卡 ¥199（365天，省 159.8）

━━ 旗舰版（含周报/文档对比/审批/团队仪表盘等） ━━
4. 月卡 ¥49.9（30天）
5. 季卡 ¥129.9（90天）
6. 年卡 ¥349.9（365天）

请回复：飞书购买 1~6`
  };
}

function handleLicenseStatus() {
  const licensePath = path.join(os.homedir(), '.openclaw', 'licenses', 'lark.json');
  if (!fs.existsSync(licensePath)) {
    return { success: false, response: '❌ 未找到授权信息\n\n请先购买或输入授权码。\n输入「飞书购买」可自助购买。' };
  }

  try {
    const lic = JSON.parse(fs.readFileSync(licensePath, 'utf8'));
    const now = Date.now();
    const remaining = lic.expiresAt ? Math.floor((lic.expiresAt - now) / (24*60*60*1000)) : -1;
    const expired = remaining <= 0;

    let msg = `📋 飞书技能授权状态\n\n`;
    msg += `授权码：${lic.code || '未知'}\n`;
    msg += `版本：${(lic.tier === 'enterprise') ? '旗舰版' : '标准版'}\n`;
    msg += `套餐类型：${lic.type || '未知'}\n`;
    msg += `到期时间：${lic.expiresAt ? new Date(lic.expiresAt).toLocaleDateString() : '未知'}\n`;
    msg += `剩余天数：${expired ? '已过期' : remaining + ' 天'}\n`;

    if (expired) {
      msg += '\n⚠️ 授权已过期，输入「飞书续费」可快速续期。';
    } else if (remaining <= 3) {
      msg += '\n⚠️ 即将到期，输入「飞书续费」可快速续期。';
    }

    return { success: true, response: msg };
  } catch (err) {
    return { success: false, response: `读取授权信息失败：${err.message}` };
  }
}

/**
 * 到期提醒：在任意命令响应中附加提醒（到期前 3 天）
 */
function getExpiryWarning() {
  const licensePath = path.join(os.homedir(), '.openclaw', 'licenses', 'lark.json');
  if (!fs.existsSync(licensePath)) return '';

  try {
    const lic = JSON.parse(fs.readFileSync(licensePath, 'utf8'));
    if (!lic.expiresAt) return '';
    const remaining = Math.floor((lic.expiresAt - Date.now()) / (24*60*60*1000));
    if (remaining <= 0) {
      return '\n\n⚠️ 您的飞书技能授权已过期。输入「飞书续费」可快速续期。';
    }
    if (remaining <= 3) {
      return `\n\n⚠️ 您的飞书技能授权将在 ${remaining} 天后到期。输入「飞书续费」可快速续期。`;
    }
  } catch (_) {}
  return '';
}

module.exports = { handleAuth, handleAuthToken, handleAuthCode, handleLogout, handleStatus, handlePurchase, handlePurchasePlan, handleRenew, handleLicenseStatus, getExpiryWarning };
