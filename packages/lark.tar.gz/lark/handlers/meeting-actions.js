/**
 * 会议纪要 → 行动项处理器
 * 提取行动项、总结纪要、对比两次会议
 *
 * FeishuAPI.request(endpoint, options) 返回已解包的 data
 */

const { withAuth } = require('../lib/with-auth');

/**
 * 搜索文档并读取内容
 */
async function fetchDocContent(docName, deps) {
  const { api } = deps;

  const result = await api.searchDocuments(docName, { pageSize: 5 });
  const files = result.files || [];
  if (files.length === 0) {
    throw new Error(`未找到文档"${docName}"`);
  }

  const match = files.find(f =>
    f.name.toLowerCase().includes(docName.toLowerCase())
  ) || files[0];

  const docInfo = await api.getDocumentContent(match.token, match.type);
  if (!docInfo || !docInfo.content) {
    throw new Error(`无法读取文档"${match.name}"的内容`);
  }

  return { name: match.name, token: match.token, content: docInfo.content, url: match.url };
}

/**
 * 在多维表格中查找指定数据表
 */
async function findTargetTable(tableName, deps) {
  const { api } = deps;

  const result = await api.searchDocuments(tableName, { pageSize: 5 });
  const bitables = (result.files || []).filter(f => f.type === 'bitable');
  if (bitables.length === 0) return null;

  const match = bitables.find(f =>
    f.name.toLowerCase().includes(tableName.toLowerCase())
  ) || bitables[0];

  const appToken = match.token;
  const data = await api.request(`/bitable/v1/apps/${appToken}/tables`);
  const tables = (data && data.items) || [];
  if (tables.length === 0) return null;

  return { appToken, tableId: tables[0].table_id, name: match.name };
}

/**
 * 将行动项写入多维表格
 */
async function writeActionsToBitable(actions, tableInfo, deps) {
  const { api } = deps;
  let written = 0;

  for (const item of actions) {
    await api.request(
      `/bitable/v1/apps/${tableInfo.appToken}/tables/${tableInfo.tableId}/records`,
      {
        method: 'POST',
        body: {
          fields: {
            '负责人': item.person,
            '任务': item.task,
            '截止日期': item.deadline,
          }
        }
      }
    );
    written++;
  }
  return written;
}

/**
 * 提取行动项
 * @param {string} docName - 会议纪要文档名
 * @param {string|null} targetTable - 目标多维表格名（可选）
 * @param {object} deps - 依赖注入
 */
async function _handleExtractActions(docName, targetTable, deps) {
  const { logger, getSummaryService, context } = deps;

  const doc = await fetchDocContent(docName, deps);

  const service = getSummaryService(context);
  const prompt = `你是一个会议纪要分析助手。请从以下会议纪要中提取所有行动项，以 JSON 数组格式返回，每个元素包含 person（负责人）、task（任务）、deadline（截止日期）、priority（优先级，P0/P1/P2）。只返回 JSON，不要其他内容。

会议纪要：
${doc.content}

输出格式示例：
[{"person": "张三", "task": "完成登录页改版设计", "deadline": "2/18", "priority": "P0"}]`;

  const result = await service.summarize(prompt, { maxLength: 2000, style: 'detailed' });

  let actions = [];
  try {
    const jsonMatch = result.summary.match(/\[[\s\S]*\]/);
    if (jsonMatch) actions = JSON.parse(jsonMatch[0]);
  } catch (e) {
    logger.warn('行动项 JSON 解析失败', { error: e.message });
    return { success: false, response: `❌ 行动项提取失败：LLM 返回格式异常` };
  }

  if (actions.length === 0) {
    return { success: true, response: `未从"${doc.name}"中提取到行动项。` };
  }

  // 格式化输出
  let response = `从"${doc.name}"中提取到 ${actions.length} 个行动项：\n\n`;
  actions.forEach((item, idx) => {
    response += `${idx + 1}. ✅ ${item.person} — ${item.task} — 截止 ${item.deadline}`;
    if (item.priority) response += ` [${item.priority}]`;
    response += '\n';
  });

  // 写入多维表格（如果指定）
  if (targetTable) {
    try {
      const tableInfo = await findTargetTable(targetTable, deps);
      if (!tableInfo) {
        response += `\n⚠️ 未找到多维表格"${targetTable}"，行动项未写入。`;
      } else {
        const written = await writeActionsToBitable(actions, tableInfo, deps);
        response += `\n已写入多维表格"${tableInfo.name}"，新增 ${written} 条记录。`;
      }
    } catch (e) {
      logger.warn('写入多维表格失败', { error: e.message });
      response += `\n⚠️ 写入多维表格失败：${e.message}`;
    }
  }

  logger.info('提取行动项', { doc: doc.name, actions: actions.length, targetTable });
  return { success: true, response };
}

/**
 * 总结会议纪要
 * @param {string} docName - 会议纪要文档名
 * @param {object} deps - 依赖注入
 */
async function _handleSummary(docName, deps) {
  const { logger, getSummaryService, context } = deps;

  const doc = await fetchDocContent(docName, deps);

  const service = getSummaryService(context);
  const prompt = `请总结以下会议纪要，重点提取关键决策和结论。用简洁的中文输出，分"会议概要"和"关键决策"两部分。

会议纪要：
${doc.content}`;

  const result = await service.summarize(prompt, { maxLength: 1500, style: 'detailed' });

  let response = `📋 "${doc.name}" 会议总结\n${'='.repeat(25)}\n\n`;
  response += result.summary;

  logger.info('会议总结', { doc: doc.name, provider: result.provider });
  return { success: true, response };
}

/**
 * 对比两次会议纪要
 * @param {string} docName1 - 较新的会议纪要
 * @param {string} docName2 - 较旧的会议纪要
 * @param {object} deps - 依赖注入
 */
async function _handleCompare(docName1, docName2, deps) {
  const { logger, getSummaryService, context } = deps;

  const [doc1, doc2] = await Promise.all([
    fetchDocContent(docName1, deps),
    fetchDocContent(docName2, deps),
  ]);

  const service = getSummaryService(context);
  const prompt = `你是一个会议纪要对比分析助手。请对比以下两份会议纪要，分析行动项的进展情况。

请按以下分类输出（使用对应的 emoji 前缀）：
✅ 已完成：在旧纪要中提到、在新纪要中确认完成的任务
🔄 进行中：两次都提到但尚未完成的任务（注明是否延期）
🆕 新增：仅在新纪要中出现的新任务
❌ 未提及：在旧纪要中有但新纪要中完全没提到的任务（可能遗漏）

【新纪要】${doc1.name}：
${doc1.content}

【旧纪要】${doc2.name}：
${doc2.content}`;

  const result = await service.summarize(prompt, { maxLength: 2000, style: 'detailed' });

  let response = `📊 纪要对比：${doc1.name} vs ${doc2.name}\n${'='.repeat(30)}\n\n`;
  response += result.summary;

  logger.info('纪要对比', { doc1: doc1.name, doc2: doc2.name, provider: result.provider });
  return { success: true, response };
}

module.exports = {
  handleExtractActions: withAuth(_handleExtractActions, '提取行动项'),
  handleSummary: withAuth(_handleSummary, '会议总结'),
  handleCompare: withAuth(_handleCompare, '纪要对比'),
};
