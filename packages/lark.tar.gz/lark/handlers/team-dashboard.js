/**
 * 团队活动仪表盘处理器
 * 文档活跃度统计、贡献排行
 * 基于 drive:drive scope 聚合文档创建/编辑数据
 *
 * FeishuAPI.request(endpoint, options) 返回已解包的 data
 */

const { withAuth } = require('../lib/with-auth');

function formatTime(ts) {
  if (!ts) return '';
  return new Date(ts * 1000).toLocaleDateString();
}

function parseDays(timeRange) {
  if (!timeRange) return 7;
  if (timeRange.includes('本周')) return 7;
  if (timeRange.includes('本月')) return 30;
  const match = timeRange.match(/(\d+)/);
  return match ? parseInt(match[1]) : 7;
}

/**
 * 团队活跃度报告
 * @param {string|null} timeRange - 时间范围描述 (本周/本月/近30天)
 */
async function _handleActivity(timeRange, deps) {
  const { api, logger } = deps;

  // 确定时间范围
  const days = parseDays(timeRange);
  const cutoff = Date.now() - days * 24 * 60 * 60 * 1000;

  // 获取最近文件列表
  const result = await api.listMyFiles({ pageSize: 50, orderBy: 'EditedTime' });
  const allFiles = result.files || [];

  // 按时间筛选
  const files = allFiles.filter(f =>
    f.edit_time && f.edit_time * 1000 >= cutoff
  );

  if (files.length === 0) {
    return { success: true, response: `📊 ${timeRange || `近${days}天`}内没有文档活动。` };
  }

  // 按类型统计
  const typeCount = {};
  files.forEach(f => {
    const t = f.type || 'unknown';
    typeCount[t] = (typeCount[t] || 0) + 1;
  });

  // 按所有者统计
  const ownerCount = {};
  files.forEach(f => {
    const owner = f.owner_name || '未知';
    ownerCount[owner] = (ownerCount[owner] || 0) + 1;
  });

  const label = timeRange || `近${days}天`;
  let response = `📊 团队活跃度报告（${label}）\n${'='.repeat(25)}\n\n`;
  response += `📄 活跃文档：${files.length} 个\n\n`;

  // 类型分布
  response += '按类型：\n';
  const typeNames = { docx: '文档', sheet: '表格', bitable: '多维表格', mindnote: '思维导图', folder: '文件夹' };
  Object.entries(typeCount)
    .sort((a, b) => b[1] - a[1])
    .forEach(([type, count]) => {
      response += `  ${typeNames[type] || type}：${count} 个\n`;
    });

  // 贡献者排行
  response += '\n按贡献者：\n';
  Object.entries(ownerCount)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .forEach(([owner, count], idx) => {
      response += `  ${idx + 1}. ${owner}：${count} 个文档\n`;
    });

  logger.info('活跃度报告', { days, fileCount: files.length });
  return { success: true, response };
}

/**
 * 文档贡献排行
 * @param {string|null} timeRange - 时间范围
 */
async function _handleContribution(timeRange, deps) {
  const { api, logger } = deps;

  const days = parseDays(timeRange);
  const cutoff = Date.now() - days * 24 * 60 * 60 * 1000;

  const result = await api.listMyFiles({ pageSize: 50, orderBy: 'EditedTime' });
  const files = (result.files || []).filter(f =>
    f.edit_time && f.edit_time * 1000 >= cutoff
  );

  if (files.length === 0) {
    return { success: true, response: `📊 ${timeRange || `近${days}天`}内没有文档贡献记录。` };
  }

  // 按所有者聚合
  const contributors = {};
  files.forEach(f => {
    const owner = f.owner_name || '未知';
    if (!contributors[owner]) contributors[owner] = { docs: [], count: 0 };
    contributors[owner].count++;
    if (contributors[owner].docs.length < 3) {
      contributors[owner].docs.push(f.name);
    }
  });

  const label = timeRange || `近${days}天`;
  let response = `🏆 文档贡献排行（${label}）\n${'='.repeat(25)}\n\n`;

  const sorted = Object.entries(contributors).sort((a, b) => b[1].count - a[1].count);
  sorted.forEach(([owner, info], idx) => {
    const medal = idx === 0 ? '🥇' : idx === 1 ? '🥈' : idx === 2 ? '🥉' : `${idx + 1}.`;
    response += `${medal} ${owner} — ${info.count} 个文档\n`;
    info.docs.forEach(d => {
      response += `   · ${d}\n`;
    });
    response += '\n';
  });

  logger.info('贡献排行', { days, contributors: sorted.length });
  return { success: true, response };
}

module.exports = {
  handleActivity: withAuth(_handleActivity, '获取活跃度报告'),
  handleContribution: withAuth(_handleContribution, '获取贡献排行'),
};
