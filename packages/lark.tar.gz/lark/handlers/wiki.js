/**
 * 知识库（Wiki）处理器
 * 搜索、问答、目录浏览
 * API: wiki:wiki:readonly scope
 *
 * FeishuAPI.request(endpoint, options) 返回已解包的 data
 */

const { withAuth } = require('../lib/with-auth');

/**
 * 搜索知识库节点
 */
async function _handleSearch(query, deps) {
  const { api, cache, logger } = deps;

  const cacheKey = `wiki:search:${query}`;
  let nodes = cache.get(cacheKey);

  if (!nodes) {
    const data = await api.request('/wiki/v1/nodes/search?page_size=20', {
      method: 'POST',
      body: { query }
    });
    nodes = (data && data.items) || [];
    cache.set(cacheKey, nodes);
  }

  if (nodes.length === 0) {
    return { success: true, response: `未在知识库中找到"${query}"相关内容。` };
  }

  let response = `📚 知识库搜索"${query}" — 找到 ${nodes.length} 个结果：\n\n`;
  nodes.slice(0, 10).forEach((node, idx) => {
    const icon = node.obj_type === 'doc' ? '📄' : node.obj_type === 'sheet' ? '📊' : '📁';
    response += `${idx + 1}. ${icon} ${node.title || '无标题'}\n`;
    if (node.space_name) response += `   📂 ${node.space_name}`;
    if (node.edit_time) {
      const date = new Date(node.edit_time * 1000);
      response += ` · ${date.toLocaleDateString()}`;
    }
    response += '\n';
    if (node.url) response += `   🔗 ${node.url}\n`;
    response += '\n';
  });

  if (nodes.length > 10) {
    response += `... 还有 ${nodes.length - 10} 个结果\n`;
  }
  response += '💡 使用"飞书知识库问答 <问题>"可以基于知识库内容进行智能问答';
  logger.info('知识库搜索', { query, results: nodes.length });
  return { success: true, response };
}

/**
 * 知识库智能问答（标准版功能）
 * 搜索相关文档 → 读取内容 → LLM 理解并回答
 */
async function _handleQA(question, deps) {
  const { api, cache, logger, getSummaryService, context } = deps;

  console.log('🔍 正在搜索知识库...');

  // 1. 搜索相关文档
  const data = await api.request('/wiki/v1/nodes/search?page_size=5', {
    method: 'POST',
    body: { query: question }
  });
  const nodes = (data && data.items) || [];

  if (nodes.length === 0) {
    return {
      success: false,
      response: `未在知识库中找到与"${question}"相关的内容。\n\n建议：\n• 尝试不同的关键词\n• 使用"飞书知识库搜索"先查看有哪些文档`
    };
  }

  console.log(`📄 找到 ${nodes.length} 个相关文档，正在阅读...`);

  // 2. 读取前 3 个文档的内容
  const contents = [];
  for (const node of nodes.slice(0, 3)) {
    try {
      if (node.obj_token && (node.obj_type === 'doc' || node.obj_type === 'docx')) {
        const docInfo = await api.getDocumentContent(node.obj_token, node.obj_type);
        if (docInfo && docInfo.content) {
          contents.push({
            title: node.title,
            content: docInfo.content.substring(0, 3000),
            url: node.url
          });
        }
      }
    } catch (e) {
      logger.warn('读取知识库文档失败', { token: node.obj_token, error: e.message });
    }
  }

  if (contents.length === 0) {
    return {
      success: false,
      response: `找到相关文档但无法读取内容。\n\n相关文档：\n${nodes.map((n, i) => `${i + 1}. ${n.title}`).join('\n')}`
    };
  }

  // 3. 使用 LLM 回答问题
  const service = getSummaryService(context);
  const combinedContent = contents.map(c =>
    `【${c.title}】\n${c.content}`
  ).join('\n\n---\n\n');

  const prompt = `基于以下飞书知识库文档内容，回答用户的问题。请直接回答，引用来源文档名称。\n\n问题：${question}\n\n文档内容：\n${combinedContent}`;

  const result = await service.summarize(prompt, {
    maxLength: 1000,
    style: 'detailed'
  });

  let response = `📚 知识库问答\n${'='.repeat(20)}\n\n`;
  response += `❓ ${question}\n\n`;
  response += result.summary + '\n\n';
  response += '---\n📖 参考来源：\n';
  contents.forEach((c, idx) => {
    response += `${idx + 1}. ${c.title}`;
    if (c.url) response += ` — ${c.url}`;
    response += '\n';
  });

  logger.info('知识库问答', { question, sources: contents.length, provider: result.provider });
  return { success: true, response };
}

/**
 * 列出知识库空间和目录
 */
async function _handleList(spaceName, deps) {
  const { api, cache, logger } = deps;

  // 获取知识空间列表
  const data = await api.request('/wiki/v2/spaces?page_size=50');
  const spaces = (data && data.items) || [];

  if (spaces.length === 0) {
    return { success: true, response: '📚 暂无可访问的知识空间。' };
  }

  // 如果指定了空间名，列出该空间的节点
  if (spaceName) {
    const space = spaces.find(s =>
      s.name && s.name.toLowerCase().includes(spaceName.toLowerCase())
    );
    if (!space) {
      return { success: false, response: `未找到名为"${spaceName}"的知识空间。` };
    }

    const nodesData = await api.request(
      `/wiki/v2/spaces/${space.space_id}/nodes?page_size=50`
    );
    const nodes = (nodesData && nodesData.items) || [];

    let response = `📚 ${space.name} — 目录\n${'='.repeat(20)}\n\n`;
    if (nodes.length === 0) {
      response += '（空）';
    } else {
      nodes.forEach((node, idx) => {
        const icon = node.obj_type === 'doc' ? '📄' : node.obj_type === 'sheet' ? '📊' : '📁';
        const indent = node.parent_node_token ? '  ' : '';
        response += `${indent}${idx + 1}. ${icon} ${node.title || '无标题'}\n`;
      });
    }

    return { success: true, response };
  }

  // 列出所有空间
  let response = `📚 知识空间列表（${spaces.length} 个）：\n\n`;
  spaces.forEach((space, idx) => {
    response += `${idx + 1}. 📂 ${space.name}`;
    if (space.description) response += ` — ${space.description}`;
    response += '\n';
  });
  response += '\n💡 使用"飞书知识库目录 <空间名>"查看具体空间的文档目录';

  logger.info('知识库目录', { spaces: spaces.length });
  return { success: true, response };
}

module.exports = {
  handleSearch: withAuth(_handleSearch, '知识库搜索'),
  handleQA: withAuth(_handleQA, '知识库问答'),
  handleList: withAuth(_handleList, '知识库目录')
};
