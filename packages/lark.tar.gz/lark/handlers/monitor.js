/**
 * 文档变更监控处理器
 * 定期轮询文档修改时间，变更时推送通知
 * 使用本地 JSON 文件持久化监控列表
 */

const fs = require('fs');
const path = require('path');
const os = require('os');
const { withAuth, withErrorHandler } = require('../lib/with-auth');

const MONITOR_FILE = path.join(os.homedir(), '.openclaw', 'skills', 'lark', 'monitors.json');

function loadMonitors() {
  try {
    if (fs.existsSync(MONITOR_FILE)) {
      return JSON.parse(fs.readFileSync(MONITOR_FILE, 'utf8'));
    }
  } catch (e) { /* ignore */ }
  return { watches: [] };
}

function saveMonitors(data) {
  const dir = path.dirname(MONITOR_FILE);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  fs.writeFileSync(MONITOR_FILE, JSON.stringify(data, null, 2));
}

/**
 * 添加文档监控
 */
async function _handleAdd(docName, frequency, deps) {
  const { api, logger, licenseGate } = deps;

  // 检查监控数量限制
  const monitors = loadMonitors();
  if (licenseGate) {
    const limit = licenseGate.getMonitorLimit();
    if (monitors.watches.length >= limit) {
      return {
        success: false,
        response: `📡 已达到监控上限（${limit} 个文档）\n\n当前监控 ${monitors.watches.length} 个文档。\n标准版最多监控 3 个文档，旗舰版无限制。\n\n升级方式：输入"飞书购买服务"了解详情`
      };
    }
  }

  // 搜索文档获取 token
  const result = await api.searchDocuments(docName, { pageSize: 5 });
  const files = result.files || [];

  if (files.length === 0) {
    return { success: false, response: `未找到名为"${docName}"的文档。` };
  }

  const doc = files.find(f =>
    f.name.toLowerCase().includes(docName.toLowerCase())
  ) || files[0];

  // 检查是否已在监控
  const existing = monitors.watches.find(w => w.token === doc.token);
  if (existing) {
    existing.frequency = frequency;
    saveMonitors(monitors);
    return {
      success: true,
      response: `📡 已更新"${doc.name}"的监控频率为 ${frequency}`
    };
  }

  // 添加新监控
  monitors.watches.push({
    token: doc.token,
    name: doc.name,
    type: doc.type,
    url: doc.url,
    frequency: frequency,
    lastEditTime: doc.edit_time || null,
    addedAt: Date.now()
  });

  saveMonitors(monitors);

  logger.info('添加文档监控', { doc: doc.name, frequency });
  return {
    success: true,
    response: `📡 已开始监控"${doc.name}"\n\n频率：${frequency}\n文档类型：${doc.type || '文档'}\n\n当文档有更新时，会通过消息通知你。\n\n💡 使用"飞书监控列表"查看所有监控`
  };
}

/**
 * 移除文档监控
 */
async function _handleRemove(docName, deps) {
  const { logger } = deps;

  const monitors = loadMonitors();
  const idx = monitors.watches.findIndex(w =>
    w.name.toLowerCase().includes(docName.toLowerCase())
  );

  if (idx === -1) {
    return { success: false, response: `未找到"${docName}"的监控记录。` };
  }

  const removed = monitors.watches.splice(idx, 1)[0];
  saveMonitors(monitors);

  logger.info('移除文档监控', { doc: removed.name });
  return {
    success: true,
    response: `✅ 已取消监控"${removed.name}"`
  };
}

/**
 * 列出所有监控
 */
async function _handleList(deps) {
  const monitors = loadMonitors();

  if (monitors.watches.length === 0) {
    return {
      success: true,
      response: '📡 当前没有监控中的文档。\n\n使用"飞书监控文档 <文档名>"开始监控。'
    };
  }

  let response = `📡 文档监控列表（${monitors.watches.length} 个）：\n\n`;

  monitors.watches.forEach((w, idx) => {
    const addedDate = new Date(w.addedAt).toLocaleDateString();
    response += `${idx + 1}. 📄 ${w.name}\n`;
    response += `   频率：${w.frequency} · 添加于 ${addedDate}\n`;
    if (w.url) response += `   🔗 ${w.url}\n`;
    response += '\n';
  });

  response += '💡 使用"飞书取消监控 <文档名>"停止监控';

  return { success: true, response };
}

/**
 * 检查文档变更（供定时任务调用）
 * @returns {Array} 变更列表
 */
async function _checkChanges(deps) {
  const { api, logger } = deps;
  const monitors = loadMonitors();
  const changes = [];

  if (monitors.watches.length === 0) return changes;

  for (const watch of monitors.watches) {
    try {
      const result = await api.searchDocuments(watch.name, { pageSize: 1 });
      const files = result.files || [];
      const doc = files.find(f => f.token === watch.token);

      if (doc && doc.edit_time && doc.edit_time !== watch.lastEditTime) {
        changes.push({
          name: watch.name,
          url: watch.url,
          oldEditTime: watch.lastEditTime,
          newEditTime: doc.edit_time
        });
        watch.lastEditTime = doc.edit_time;
      }
    } catch (e) {
      logger.warn('检查文档变更失败', { doc: watch.name, error: e.message });
    }

    // 避免限流
    await new Promise(r => setTimeout(r, 500));
  }

  if (changes.length > 0) {
    saveMonitors(monitors);
  }

  return changes;
}

module.exports = {
  handleAdd: withAuth(_handleAdd, '添加监控'),
  handleRemove: withErrorHandler(_handleRemove, '取消监控'),
  handleList: withErrorHandler(_handleList, '获取监控列表'),
  checkChanges: withAuth(_checkChanges, '检查变更'),
};