/**
 * 云文档（Drive）处理器
 * 搜索、列表、最近修改、详情
 * API: drive:drive scope
 *
 * FeishuAPI.request(endpoint, options) 返回已解包的 data
 */

const { withAuth } = require('../lib/with-auth');

const FILE_ICONS = {
  docx: '📄', doc: '📄',
  sheet: '📊',
  mindnote: '🧠',
  bitable: '📋',
  folder: '📂',
  file: '📁'
};

function getIcon(type) {
  return FILE_ICONS[type] || '📁';
}

function formatTime(ts) {
  if (!ts) return '';
  return new Date(ts * 1000).toLocaleDateString();
}

/**
 * 搜索云文档
 */
async function _handleSearch(query, fileType, deps) {
  const { api, cache, logger } = deps;

  const cacheKey = `drive:search:${query}:${fileType || ''}`;
  let files = cache.get(cacheKey);

  if (!files) {
    const result = await api.searchDocuments(query, { pageSize: 20 });
    files = result.files || [];
    cache.set(cacheKey, files);
  }

  // 按类型筛选
  if (fileType) {
    const typeMap = { '文档': 'docx', '表格': 'sheet', '文件夹': 'folder' };
    const mapped = typeMap[fileType];
    if (mapped) {
      files = files.filter(f => f.type === mapped);
    }
  }

  if (files.length === 0) {
    return { success: true, response: `未找到"${query}"相关的云文档。` };
  }

  let response = `🔍 搜索"${query}"${fileType ? `（${fileType}）` : ''} — 找到 ${files.length} 个结果：\n\n`;
  files.slice(0, 10).forEach((f, idx) => {
    response += `${idx + 1}. ${getIcon(f.type)} ${f.name}\n`;
    const meta = [];
    if (f.owner_name) meta.push(f.owner_name);
    if (f.edit_time) meta.push(formatTime(f.edit_time));
    if (meta.length) response += `   ${meta.join(' · ')}\n`;
    if (f.url) response += `   🔗 ${f.url}\n`;
    response += '\n';
  });

  if (files.length > 10) {
    response += `... 还有 ${files.length - 10} 个结果\n`;
  }

  logger.info('云文档搜索', { query, fileType, results: files.length });
  return { success: true, response };
}

/**
 * 列出文件夹内容
 */
async function _handleList(folderPath, deps) {
  const { api, cache, logger } = deps;

  const opts = { pageSize: 20, orderBy: 'EditedTime' };
  if (folderPath) opts.folderToken = folderPath;

  const cacheKey = `drive:list:${folderPath || 'root'}`;
  let files = cache.get(cacheKey);

  if (!files) {
    const result = await api.listMyFiles(opts);
    files = result.files || [];
    cache.set(cacheKey, files);
  }

  if (files.length === 0) {
    return { success: true, response: '📂 该文件夹为空。' };
  }

  let response = `📂 ${folderPath ? '文件夹' : '我的云文档'}（${files.length} 个文件）：\n\n`;
  files.forEach((f, idx) => {
    response += `${idx + 1}. ${getIcon(f.type)} ${f.name}\n`;
    if (f.edit_time) response += `   修改于 ${formatTime(f.edit_time)}\n`;
  });

  logger.info('云文档列表', { folder: folderPath || 'root', count: files.length });
  return { success: true, response };
}

/**
 * 最近修改的文件
 */
async function _handleRecent(days, deps) {
  const { api, cache, logger } = deps;

  const cacheKey = `drive:recent:${days}`;
  let files = cache.get(cacheKey);

  if (!files) {
    const result = await api.listMyFiles({ pageSize: 20, orderBy: 'EditedTime' });
    files = result.files || [];
    cache.set(cacheKey, files);
  }

  const cutoff = Date.now() - days * 24 * 60 * 60 * 1000;
  files = files.filter(f => f.edit_time && f.edit_time * 1000 >= cutoff);

  if (files.length === 0) {
    return { success: true, response: `最近 ${days} 天内没有修改过的文件。` };
  }

  let response = `🕐 最近 ${days} 天修改的文件（${files.length} 个）：\n\n`;
  files.forEach((f, idx) => {
    response += `${idx + 1}. ${getIcon(f.type)} ${f.name}\n`;
    response += `   修改于 ${formatTime(f.edit_time)}`;
    if (f.owner_name) response += ` · ${f.owner_name}`;
    response += '\n';
  });

  logger.info('最近文件', { days, count: files.length });
  return { success: true, response };
}

/**
 * 文件详情
 */
async function _handleDetail(fileName, deps) {
  const { api, cache, logger } = deps;

  // 先搜索找到文件
  const result = await api.searchDocuments(fileName, { pageSize: 5 });
  const files = result.files || [];
  const file = files.find(f =>
    f.name.toLowerCase() === fileName.toLowerCase() ||
    f.name.toLowerCase().includes(fileName.toLowerCase())
  ) || files[0];

  if (!file) {
    return { success: false, response: `未找到名为"${fileName}"的文件。` };
  }

  let response = `${getIcon(file.type)} ${file.name}\n${'='.repeat(20)}\n\n`;
  response += `类型：${file.type}\n`;
  if (file.owner_name) response += `所有者：${file.owner_name}\n`;
  if (file.create_time) response += `创建时间：${formatTime(file.create_time)}\n`;
  if (file.edit_time) response += `修改时间：${formatTime(file.edit_time)}\n`;
  if (file.token) response += `Token：${file.token}\n`;
  if (file.url) response += `链接：${file.url}\n`;

  logger.info('文件详情', { name: fileName, type: file.type });
  return { success: true, response };
}

/**
 * AI 周报生成
 * 获取最近 N 天编辑的文档，读取内容，用 LLM 生成周报摘要
 */
async function _handleWeeklyReport(days, deps) {
  const { api, cache, logger, getSummaryService, context } = deps;

  console.log(`📊 正在获取最近 ${days} 天编辑的文档...`);

  // 1. 获取最近编辑的文档
  const result = await api.listMyFiles({ pageSize: 50, orderBy: 'EditedTime' });
  let files = result.files || [];

  const cutoff = Date.now() - days * 24 * 60 * 60 * 1000;
  files = files.filter(f => f.edit_time && f.edit_time * 1000 >= cutoff);

  if (files.length === 0) {
    return { success: true, response: `最近 ${days} 天内没有编辑过文档，无法生成周报。` };
  }

  console.log(`📄 找到 ${files.length} 个文档，正在读取内容...`);

  // 2. 读取文档内容（最多 10 篇）
  const docSummaries = [];
  for (const file of files.slice(0, 10)) {
    try {
      const docInfo = await api.getDocumentContent(file.token, file.type);
      if (docInfo && docInfo.content) {
        docSummaries.push({
          title: file.name,
          type: file.type,
          editTime: formatTime(file.edit_time),
          content: docInfo.content.substring(0, 2000)
        });
      }
    } catch (e) {
      // 部分文档可能无法读取，跳过
      docSummaries.push({
        title: file.name,
        type: file.type,
        editTime: formatTime(file.edit_time),
        content: ''
      });
    }
  }

  // 3. 用 LLM 生成周报
  const service = getSummaryService(context);
  const docsText = docSummaries.map((d, i) =>
    `【${i + 1}. ${d.title}】(${d.editTime})\n${d.content || '（内容未获取）'}`
  ).join('\n\n---\n\n');

  const prompt = `你是一个工作周报助手。根据以下用户最近 ${days} 天编辑的飞书文档，生成一份简洁的工作周报。

要求：
1. 按工作类别分组（如：产品、技术、运营等）
2. 每项工作用一句话概括
3. 最后给出本周重点和下周计划建议
4. 使用中文，语言简洁专业

文档列表：
${docsText}`;

  const reportResult = await service.summarize(prompt, {
    maxLength: 1000,
    language: 'zh',
    style: 'professional'
  });

  const providerInfo = service.getProviderInfo();

  // 4. 格式化输出
  let response = `📋 AI 周报（最近 ${days} 天）\n`;
  response += '='.repeat(40) + '\n\n';
  response += `📊 基于 ${docSummaries.length} 篇文档生成`;
  if (providerInfo.name !== 'basic') {
    response += ` (${providerInfo.model})`;
  }
  response += '\n\n';
  response += reportResult.summary || reportResult;
  response += '\n\n' + '='.repeat(40);
  response += `\n📄 涉及文档：\n`;
  docSummaries.forEach((d, i) => {
    response += `  ${i + 1}. ${getIcon(d.type)} ${d.title} (${d.editTime})\n`;
  });

  logger.info('周报生成', { days, docCount: docSummaries.length });
  return { success: true, response };
}

module.exports = {
  handleSearch: withAuth(_handleSearch, '云文档搜索'),
  handleList: withAuth(_handleList, '云文档列表'),
  handleRecent: withAuth(_handleRecent, '最近文件查询'),
  handleDetail: withAuth(_handleDetail, '文件详情查询'),
  handleWeeklyReport: withAuth(_handleWeeklyReport, '周报生成'),
};
