/**
 * 多维表格（Bitable）处理器
 * 支持对话式 CRUD 操作
 * API: bitable:app scope
 *
 * 注意：FeishuAPI.request(endpoint, options) 签名：
 *   endpoint: 不含 baseURL 的路径，如 '/bitable/v1/apps/xxx/tables'
 *   options: { method, body, headers, timeout }
 *   返回值: 已解包的 result.data（不是 { data: ... }）
 */

const { withAuth } = require('../lib/with-auth');

/**
 * 解析 "字段=值" 格式的筛选/更新条件
 */
function parseFieldValues(str) {
  const pairs = {};
  const parts = str.split(/\s+(?=\S+=)/);
  for (const part of parts) {
    const eqIdx = part.indexOf('=');
    if (eqIdx > 0) {
      const key = part.substring(0, eqIdx).trim();
      const val = part.substring(eqIdx + 1).trim();
      pairs[key] = val;
    }
  }
  return pairs;
}

/**
 * 通过名称搜索多维表格，返回 app_token
 */
async function findBitable(tableName, deps) {
  const { api, cache } = deps;

  const cacheKey = `bitable:find:${tableName}`;
  let cached = cache.get(cacheKey);
  if (cached) return cached;

  const result = await api.searchDocuments(tableName, { pageSize: 10 });
  const files = (result.files || []).filter(f => f.type === 'bitable');

  if (files.length === 0) return null;

  const match = files.find(f =>
    f.name.toLowerCase() === tableName.toLowerCase() ||
    f.name.toLowerCase().includes(tableName.toLowerCase())
  ) || files[0];

  const info = { appToken: match.token, name: match.name, url: match.url };
  cache.set(cacheKey, info);
  return info;
}

/**
 * 获取表格的第一个数据表（table）信息
 */
async function getFirstTable(appToken, deps) {
  const { api } = deps;
  const data = await api.request(`/bitable/v1/apps/${appToken}/tables`);
  const tables = data && data.items;
  if (!tables || tables.length === 0) {
    throw new Error('该多维表格中没有数据表');
  }
  return tables[0];
}

/**
 * 获取字段列表
 */
async function getFields(appToken, tableId, deps) {
  const { api } = deps;
  const data = await api.request(`/bitable/v1/apps/${appToken}/tables/${tableId}/fields`);
  return (data && data.items) || [];
}

/**
 * 构建筛选条件
 */
function buildFilter(filterStr, fields) {
  if (!filterStr) return null;
  const pairs = parseFieldValues(filterStr);
  const conditions = [];

  for (const [key, val] of Object.entries(pairs)) {
    const field = fields.find(f => f.field_name === key);
    if (field) {
      conditions.push({ field_name: key, operator: 'is', value: [val] });
    }
  }

  if (conditions.length === 0) return null;
  return { conjunction: 'and', conditions };
}

/**
 * 查询表格记录
 */
async function _handleQuery(tableName, filterStr, deps) {
  const { api, logger } = deps;

  const bitable = await findBitable(tableName, deps);
  if (!bitable) {
    return { success: false, response: `未找到名为"${tableName}"的多维表格。` };
  }

  const table = await getFirstTable(bitable.appToken, deps);
  const fields = await getFields(bitable.appToken, table.table_id, deps);

  let endpoint = `/bitable/v1/apps/${bitable.appToken}/tables/${table.table_id}/records?page_size=50`;
  if (filterStr) {
    const filter = buildFilter(filterStr, fields);
    if (filter) endpoint += `&filter=${encodeURIComponent(JSON.stringify(filter))}`;
  }

  const data = await api.request(endpoint);
  const records = (data && data.items) || [];

  if (records.length === 0) {
    return { success: true, response: `📋 ${bitable.name} — 未找到匹配记录${filterStr ? `（筛选：${filterStr}）` : ''}` };
  }

  let response = `📋 ${bitable.name}（${table.name}）\n`;
  response += `找到 ${records.length} 条记录${filterStr ? `（筛选：${filterStr}）` : ''}：\n\n`;

  records.slice(0, 20).forEach((record, idx) => {
    const vals = record.fields || {};
    const parts = [];
    for (const field of fields.slice(0, 5)) {
      const v = vals[field.field_name];
      if (v !== undefined && v !== null) {
        const display = Array.isArray(v) ? v.map(item => item.text || item.name || item).join(', ') :
                        typeof v === 'object' ? (v.text || v.name || JSON.stringify(v)) : String(v);
        parts.push(`${field.field_name}: ${display}`);
      }
    }
    response += `${idx + 1}. ${parts.join(' — ')}\n`;
  });

  if (records.length > 20) {
    response += `\n... 还有 ${records.length - 20} 条记录`;
  }

  logger.info('表格查询', { table: tableName, count: records.length });
  return { success: true, response };
}

/**
 * 更新表格记录
 */
async function _handleUpdate(tableName, updatesStr, filterStr, deps) {
  const { api, logger } = deps;

  const bitable = await findBitable(tableName, deps);
  if (!bitable) {
    return { success: false, response: `未找到名为"${tableName}"的多维表格。` };
  }

  const table = await getFirstTable(bitable.appToken, deps);
  const fields = await getFields(bitable.appToken, table.table_id, deps);

  // 先查询匹配的记录
  let endpoint = `/bitable/v1/apps/${bitable.appToken}/tables/${table.table_id}/records?page_size=100`;
  const filter = buildFilter(filterStr, fields);
  if (filter) endpoint += `&filter=${encodeURIComponent(JSON.stringify(filter))}`;

  const data = await api.request(endpoint);
  const records = (data && data.items) || [];

  if (records.length === 0) {
    return { success: false, response: `未找到匹配条件"${filterStr}"的记录。` };
  }

  const updates = parseFieldValues(updatesStr);
  let updatedCount = 0;

  for (const record of records) {
    try {
      await api.request(
        `/bitable/v1/apps/${bitable.appToken}/tables/${table.table_id}/records/${record.record_id}`,
        { method: 'PUT', body: { fields: updates } }
      );
      updatedCount++;
    } catch (e) {
      logger.warn('更新记录失败', { recordId: record.record_id, error: e.message });
    }
    if (records.length > 1) await new Promise(r => setTimeout(r, 200));
  }

  logger.info('表格更新', { table: tableName, updated: updatedCount });
  return {
    success: true,
    response: `✅ 已更新 ${updatedCount} 条记录\n\n表格：${bitable.name}\n条件：${filterStr}\n更新：${updatesStr}`
  };
}

/**
 * 新增记录
 */
async function _handleCreate(tableName, fieldsStr, deps) {
  const { api, logger } = deps;

  const bitable = await findBitable(tableName, deps);
  if (!bitable) {
    return { success: false, response: `未找到名为"${tableName}"的多维表格。` };
  }

  const table = await getFirstTable(bitable.appToken, deps);
  const fieldValues = parseFieldValues(fieldsStr);

  await api.request(
    `/bitable/v1/apps/${bitable.appToken}/tables/${table.table_id}/records`,
    { method: 'POST', body: { fields: fieldValues } }
  );

  const parts = Object.entries(fieldValues).map(([k, v]) => `${k}=${v}`).join(', ');
  logger.info('新增记录', { table: tableName });
  return {
    success: true,
    response: `✅ 已在"${bitable.name}"中新增 1 条记录\n\n${parts}`
  };
}

/**
 * 表格统计
 */
async function _handleStats(tableName, deps) {
  const { api, logger } = deps;

  const bitable = await findBitable(tableName, deps);
  if (!bitable) {
    return { success: false, response: `未找到名为"${tableName}"的多维表格。` };
  }

  const table = await getFirstTable(bitable.appToken, deps);
  const fields = await getFields(bitable.appToken, table.table_id, deps);

  const data = await api.request(
    `/bitable/v1/apps/${bitable.appToken}/tables/${table.table_id}/records?page_size=1`
  );
  const total = (data && data.total) || 0;

  let response = `📊 ${bitable.name} — 统计\n${'='.repeat(30)}\n\n`;
  response += `数据表：${table.name}\n`;
  response += `记录总数：${total}\n`;
  response += `字段数：${fields.length}\n\n`;

  response += '字段列表：\n';
  fields.forEach((f, idx) => {
    const typeMap = { 1: '文本', 2: '数字', 3: '单选', 4: '多选', 5: '日期', 7: '复选框', 11: '人员', 13: '电话', 15: '链接', 17: '附件', 18: '关联', 20: '公式', 22: '创建时间', 23: '修改时间', 1001: '创建人', 1002: '修改人' };
    response += `  ${idx + 1}. ${f.field_name} (${typeMap[f.type] || `类型${f.type}`})\n`;
  });

  if (bitable.url) {
    response += `\n🔗 ${bitable.url}`;
  }

  logger.info('表格统计', { table: tableName, total, fields: fields.length });
  return { success: true, response };
}

module.exports = {
  handleQuery: withAuth(_handleQuery, '查询表格'),
  handleUpdate: withAuth(_handleUpdate, '更新表格'),
  handleCreate: withAuth(_handleCreate, '新增记录'),
  handleStats: withAuth(_handleStats, '表格统计'),
};
