/**
 * 文本处理工具函数
 * 从 utils.js 提取，供 LLM 降级使用
 */

/**
 * 简单的文档内容提取（模拟 AI 总结）
 */
function extractSummary(content, maxLength = 500) {
  if (!content) return '暂无内容';

  // 移除 HTML 标签
  let text = content.replace(/<[^>]+>/g, ' ');

  // 移除多余空白
  text = text.replace(/\s+/g, ' ').trim();

  // 提取前 maxLength 个字符
  if (text.length <= maxLength) return text;

  // 尝试在句号处截断
  const truncated = text.substring(0, maxLength);
  const lastPeriod = truncated.lastIndexOf('。');

  if (lastPeriod > maxLength * 0.7) {
    return truncated.substring(0, lastPeriod + 1) + '...';
  }

  return truncated + '...';
}

/**
 * 提取关键词
 */
function extractKeywords(text, count = 5) {
  if (!text) return [];

  // 简单的中文分词模拟
  const commonWords = new Set(['的', '了', '是', '在', '我', '有', '和', '就', '不', '人', '都', '一', '一个', '上', '也', '很', '到', '说', '要', '去', '你', '会', '着', '没有', '看', '好', '自己', '这']);

  const words = text.split(/[\s\n，。！？、：""''（）【】《》]/);
  const freq = {};

  for (const word of words) {
    const clean = word.trim();
    if (clean.length >= 2 && !commonWords.has(clean)) {
      freq[clean] = (freq[clean] || 0) + 1;
    }
  }

  return Object.entries(freq)
    .sort((a, b) => b[1] - a[1])
    .slice(0, count)
    .map(([word]) => word);
}

module.exports = {
  extractSummary,
  extractKeywords
};
