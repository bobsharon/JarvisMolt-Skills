/**
 * Claude (Anthropic) LLM 提供商
 */

const BaseLLMProvider = require('./base-provider');
const https = require('https');

class ClaudeProvider extends BaseLLMProvider {
  constructor(config = {}) {
    super(config);
    this.apiKey = config.apiKey || process.env.ANTHROPIC_API_KEY;
    this.model = config.model || process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-5-20250929';
    this.baseURL = config.baseURL || process.env.ANTHROPIC_BASE_URL || 'https://api.anthropic.com';
  }

  async summarize(content, options = {}) {
    const {
      maxLength = 500,
      language = 'auto',
      style = 'concise'
    } = options;

    const prompt = this.buildSummaryPrompt(content, { maxLength, language, style });

    try {
      const response = await this.callClaude(prompt);
      return {
        summary: response.content[0].text,
        provider: 'claude',
        model: this.model,
        tokens: (response.usage.input_tokens || 0) + (response.usage.output_tokens || 0)
      };
    } catch (error) {
      throw new Error(`Claude 总结失败: ${error.message}`);
    }
  }

  async extractKeywords(content, count = 5) {
    const prompt = `请从以下文档中提取 ${count} 个最重要的关键词，只返回关键词列表，用逗号分隔：\n\n${content.substring(0, 2000)}`;

    try {
      const response = await this.callClaude(prompt);
      const keywords = response.content[0].text
        .split(/[,，、]/)
        .map(k => k.trim())
        .filter(k => k.length > 0)
        .slice(0, count);

      return keywords;
    } catch (error) {
      throw new Error(`Claude 关键词提取失败: ${error.message}`);
    }
  }

  buildSummaryPrompt(content, options) {
    const { maxLength, language, style } = options;

    let styleInstruction = '';
    if (style === 'concise') {
      styleInstruction = '请用简洁的语言总结';
    } else if (style === 'detailed') {
      styleInstruction = '请详细总结';
    } else if (style === 'bullet') {
      styleInstruction = '请用要点形式总结';
    }

    let languageInstruction = '';
    if (language === 'zh') {
      languageInstruction = '用中文';
    } else if (language === 'en') {
      languageInstruction = '用英文';
    } else {
      languageInstruction = '用文档的原始语言';
    }

    return `${styleInstruction}以下文档的核心内容，${languageInstruction}，控制在 ${maxLength} 字以内：

${content.substring(0, 4000)}

总结：`;
  }

  async callClaude(prompt) {
    const url = new URL(`${this.baseURL}/v1/messages`);

    const postData = JSON.stringify({
      model: this.model,
      messages: [
        { role: 'user', content: prompt }
      ],
      max_tokens: 1000
    });

    return new Promise((resolve, reject) => {
      const req = https.request({
        hostname: url.hostname,
        path: url.pathname,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': this.apiKey,
          'anthropic-version': '2023-06-01',
          'Content-Length': Buffer.byteLength(postData)
        }
      }, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          try {
            const result = JSON.parse(data);
            if (result.error) {
              reject(new Error(result.error.message));
            } else {
              resolve(result);
            }
          } catch (error) {
            reject(error);
          }
        });
      });

      req.on('error', reject);
      req.write(postData);
      req.end();
    });
  }

  async isAvailable() {
    return !!this.apiKey;
  }

  getInfo() {
    return {
      name: 'Claude',
      model: this.model,
      available: !!this.apiKey
    };
  }
}

module.exports = ClaudeProvider;
