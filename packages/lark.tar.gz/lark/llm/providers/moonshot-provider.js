/**
 * Moonshot (月之暗面) LLM 提供商
 * OpenAI 兼容接口
 */

const OpenAIProvider = require('./openai-provider');

class MoonshotProvider extends OpenAIProvider {
  constructor(config = {}) {
    super({
      providerName: 'moonshot',
      apiKey: config.apiKey || process.env.MOONSHOT_API_KEY || process.env.KIMI_API_KEY,
      model: config.model || process.env.MOONSHOT_MODEL || process.env.KIMI_MODEL || 'kimi-k2.5',
      baseURL: config.baseURL || process.env.MOONSHOT_BASE_URL || process.env.KIMI_BASE_URL || 'https://api.moonshot.cn/v1',
      ...config,
    });
  }
}

module.exports = MoonshotProvider;
