/**
 * 基础 LLM 提供商接口
 */

class BaseLLMProvider {
  constructor(config = {}) {
    this.config = config;
  }

  /**
   * 生成文档总结
   * @param {string} content - 文档内容
   * @param {object} options - 总结选项
   * @param {number} options.maxLength - 最大长度
   * @param {string} options.language - 语言 (auto|zh|en)
   * @param {string} options.style - 风格 (concise|detailed|bullet)
   * @returns {Promise<object>} 总结结果
   */
  async summarize(content, options = {}) {
    throw new Error('summarize() must be implemented');
  }

  /**
   * 提取关键词
   * @param {string} content - 文档内容
   * @param {number} count - 关键词数量
   * @returns {Promise<string[]>} 关键词列表
   */
  async extractKeywords(content, count = 5) {
    throw new Error('extractKeywords() must be implemented');
  }

  /**
   * 检查提供商是否可用
   * @returns {Promise<boolean>}
   */
  async isAvailable() {
    return false;
  }

  /**
   * 获取提供商信息
   * @returns {object}
   */
  getInfo() {
    return {
      name: this.constructor.name.replace('Provider', ''),
      model: this.config.model || 'unknown',
      available: false
    };
  }
}

module.exports = BaseLLMProvider;
