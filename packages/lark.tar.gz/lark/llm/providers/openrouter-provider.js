/**
 * OpenRouter LLM 提供商
 * 统一网关，可访问多家模型
 * OpenAI 兼容接口
 */

const OpenAIProvider = require('./openai-provider');

class OpenRouterProvider extends OpenAIProvider {
  constructor(config = {}) {
    super({
      providerName: 'openrouter',
      apiKey: config.apiKey || process.env.OPENROUTER_API_KEY,
      model: config.model || process.env.OPENROUTER_MODEL || 'anthropic/claude-sonnet-4-5',
      baseURL: config.baseURL || process.env.OPENROUTER_BASE_URL || 'https://openrouter.ai/api/v1',
      ...config,
    });
  }
}

module.exports = OpenRouterProvider;
