/**
 * OpenAI LLM 提供商
 */

const BaseLLMProvider = require('./base-provider');
const https = require('https');

class OpenAIProvider extends BaseLLMProvider {
  constructor(config = {}) {
    super(config);
    this.providerName = config.providerName || 'openai';
    this.apiKey = config.apiKey || process.env.OPENAI_API_KEY;
    this.model = config.model || process.env.OPENAI_MODEL || 'gpt-5-mini';
    this.baseURL = config.baseURL || process.env.OPENAI_BASE_URL || 'https://api.openai.com/v1';
  }

  /**
   * 生成文档总结
   */
  async summarize(content, options = {}) {
    const {
      maxLength = 500,
      language = 'auto',
      style = 'concise'
    } = options;

    const prompt = this.buildSummaryPrompt(content, { maxLength, language, style });

    try {
      const response = await this.callOpenAI(prompt);
      return {
        summary: response.choices[0].message.content,
        provider: this.providerName,
        model: this.model,
        tokens: response.usage.total_tokens
      };
    } catch (error) {
      throw new Error(`${this.providerName} 总结失败: ${error.message}`);
    }
  }

  /**
   * 提取关键词
   */
  async extractKeywords(content, count = 5) {
    const prompt = `请从以下文档中提取 ${count} 个最重要的关键词，只返回关键词列表，用逗号分隔：\n\n${content.substring(0, 2000)}`;

    try {
      const response = await this.callOpenAI(prompt);
      const keywords = response.choices[0].message.content
        .split(/[,，、]/)
        .map(k => k.trim())
        .filter(k => k.length > 0)
        .slice(0, count);

      return keywords;
    } catch (error) {
      throw new Error(`${this.providerName} 关键词提取失败: ${error.message}`);
    }
  }

  /**
   * 构建总结提示词
   */
  buildSummaryPrompt(content, options) {
    const { maxLength, language, style } = options;

    let styleInstruction = '';
    if (style === 'concise') {
      styleInstruction = '请用简洁的语言总结';
    } else if (style === 'detailed') {
      styleInstruction = '请详细总结';
    } else if (style === 'bullet') {
      styleInstruction = '请用要点形式总结';
    }

    let languageInstruction = '';
    if (language === 'zh') {
      languageInstruction = '用中文';
    } else if (language === 'en') {
      languageInstruction = '用英文';
    } else {
      languageInstruction = '用文档的原始语言';
    }

    return `${styleInstruction}以下文档的核心内容，${languageInstruction}，控制在 ${maxLength} 字以内：

${content.substring(0, 4000)}

总结：`;
  }

  /**
   * 调用 OpenAI API
   */
  async callOpenAI(prompt) {
    const url = new URL(`${this.baseURL}/chat/completions`);

    const postData = JSON.stringify({
      model: this.model,
      messages: [
        { role: 'user', content: prompt }
      ],
      temperature: 0.3,
      max_tokens: 1000
    });

    return new Promise((resolve, reject) => {
      const req = https.request({
        hostname: url.hostname,
        path: url.pathname,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Length': Buffer.byteLength(postData)
        }
      }, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          try {
            const result = JSON.parse(data);
            if (result.error) {
              reject(new Error(result.error.message));
            } else {
              resolve(result);
            }
          } catch (error) {
            reject(error);
          }
        });
      });

      req.on('error', reject);
      req.write(postData);
      req.end();
    });
  }

  /**
   * 检查提供商是否可用
   */
  async isAvailable() {
    return !!this.apiKey;
  }

  /**
   * 获取提供商信息
   */
  getInfo() {
    return {
      name: this.providerName.charAt(0).toUpperCase() + this.providerName.slice(1),
      model: this.model,
      available: !!this.apiKey
    };
  }
}

module.exports = OpenAIProvider;
