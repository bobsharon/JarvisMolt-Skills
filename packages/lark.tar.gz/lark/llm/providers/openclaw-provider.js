/**
 * OpenClaw 主模型提供商
 * 使用 OpenClaw 的默认 LLM 模型
 */

const BaseLLMProvider = require('./base-provider');

class OpenClawProvider extends BaseLLMProvider {
  constructor(config = {}) {
    super(config);
    this.context = config.context; // OpenClaw 的 context 对象
  }

  /**
   * 生成文档总结
   */
  async summarize(content, options = {}) {
    const {
      maxLength = 500,
      language = 'auto',
      style = 'concise'
    } = options;

    const prompt = this.buildSummaryPrompt(content, { maxLength, language, style });

    try {
      // 使用 OpenClaw 的主模型
      if (!this.context || !this.context.llm) {
        throw new Error('OpenClaw LLM 不可用');
      }

      const response = await this.context.llm.complete(prompt);

      return {
        summary: response.text || response,
        provider: 'openclaw',
        model: this.context.llm.model || 'default',
        tokens: response.usage?.total_tokens || 0
      };
    } catch (error) {
      throw new Error(`OpenClaw 总结失败: ${error.message}`);
    }
  }

  /**
   * 提取关键词
   */
  async extractKeywords(content, count = 5) {
    const prompt = `请从以下文档中提取 ${count} 个最重要的关键词，只返回关键词列表，用逗号分隔：\n\n${content.substring(0, 2000)}`;

    try {
      if (!this.context || !this.context.llm) {
        throw new Error('OpenClaw LLM 不可用');
      }

      const response = await this.context.llm.complete(prompt);
      const text = response.text || response;

      const keywords = text
        .split(/[,，、]/)
        .map(k => k.trim())
        .filter(k => k.length > 0)
        .slice(0, count);

      return keywords;
    } catch (error) {
      throw new Error(`OpenClaw 关键词提取失败: ${error.message}`);
    }
  }

  /**
   * 构建总结提示词
   */
  buildSummaryPrompt(content, options) {
    const { maxLength, language, style } = options;

    let styleInstruction = '';
    if (style === 'concise') {
      styleInstruction = '请用简洁的语言总结';
    } else if (style === 'detailed') {
      styleInstruction = '请详细总结';
    } else if (style === 'bullet') {
      styleInstruction = '请用要点形式总结';
    }

    let languageInstruction = '';
    if (language === 'zh') {
      languageInstruction = '用中文';
    } else if (language === 'en') {
      languageInstruction = '用英文';
    } else {
      languageInstruction = '用文档的原始语言';
    }

    return `${styleInstruction}以下文档的核心内容，${languageInstruction}，控制在 ${maxLength} 字以内：

${content.substring(0, 4000)}

总结：`;
  }

  /**
   * 检查提供商是否可用
   */
  async isAvailable() {
    return !!(this.context && this.context.llm);
  }

  /**
   * 获取提供商信息
   */
  getInfo() {
    return {
      name: 'OpenClaw',
      model: this.context?.llm?.model || 'default',
      available: !!(this.context && this.context.llm)
    };
  }
}

module.exports = OpenClawProvider;
