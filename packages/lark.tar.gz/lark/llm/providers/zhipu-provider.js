/**
 * 智谱 AI (ZhipuAI / GLM) LLM 提供商
 * OpenAI 兼容接口
 */

const OpenAIProvider = require('./openai-provider');

class ZhipuProvider extends OpenAIProvider {
  constructor(config = {}) {
    super({
      providerName: 'zhipu',
      apiKey: config.apiKey || process.env.ZHIPU_API_KEY || process.env.GLM_API_KEY,
      model: config.model || process.env.ZHIPU_MODEL || 'glm-4.7-flash',
      baseURL: config.baseURL || process.env.ZHIPU_BASE_URL || 'https://open.bigmodel.cn/api/paas/v4',
      ...config,
    });
  }
}

module.exports = ZhipuProvider;
