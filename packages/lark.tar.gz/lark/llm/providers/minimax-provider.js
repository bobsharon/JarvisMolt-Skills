/**
 * MiniMax (稀宇科技) LLM 提供商
 * OpenAI 兼容接口
 */

const OpenAIProvider = require('./openai-provider');

class MiniMaxProvider extends OpenAIProvider {
  constructor(config = {}) {
    super({
      providerName: 'minimax',
      apiKey: config.apiKey || process.env.MINIMAX_API_KEY,
      model: config.model || process.env.MINIMAX_MODEL || 'MiniMax-M2.5',
      baseURL: config.baseURL || process.env.MINIMAX_BASE_URL || 'https://api.minimax.chat/v1',
      ...config,
    });
  }
}

module.exports = MiniMaxProvider;
