/**
 * 智能总结服务
 * 支持多个 LLM 提供商，优雅降级到基础算法
 */

const { extractSummary, extractKeywords } = require('./text-utils');

// 提供商名称 → 构造函数映射
const PROVIDER_MAP = {
  openai: require('./providers/openai-provider'),
  claude: require('./providers/claude-provider'),
  moonshot: require('./providers/moonshot-provider'),
  minimax: require('./providers/minimax-provider'),
  zhipu: require('./providers/zhipu-provider'),
  glm: require('./providers/zhipu-provider'),
  openrouter: require('./providers/openrouter-provider'),
};

// 显示名称
const PROVIDER_LABEL = {
  openai: 'OpenAI',
  claude: 'Claude',
  moonshot: 'Moonshot (月之暗面)',
  minimax: 'MiniMax (稀宇)',
  zhipu: '智谱 GLM',
  glm: '智谱 GLM',
  openrouter: 'OpenRouter',
};

class SummaryService {
  constructor(config = {}) {
    this.config = config;
    this.provider = null;
    this.context = config.context; // OpenClaw context
    this.initProvider();
  }

  /**
   * 初始化 LLM 提供商
   * 优先级：OpenClaw 主模型 > 用户配置的提供商 > 基础算法
   */
  initProvider() {
    try {
      // 优先使用 OpenClaw 的主模型（如果可用）
      if (this.context && this.context.llm) {
        const OpenClawProvider = require('./providers/openclaw-provider');
        this.provider = new OpenClawProvider({ context: this.context });
        console.log('✨ 使用 OpenClaw 主模型进行智能总结');
        return;
      }

      // 其次使用用户配置的提供商
      const providerType = (process.env.FEISHU_LLM_PROVIDER || 'none').toLowerCase();
      const ProviderClass = PROVIDER_MAP[providerType];

      if (ProviderClass) {
        this.provider = new ProviderClass(this.config);
        console.log(`✨ 使用 ${PROVIDER_LABEL[providerType] || providerType} 进行智能总结`);
      } else {
        this.provider = null;
      }
    } catch (error) {
      console.warn('⚠️ LLM 提供商初始化失败，将使用基础算法:', error.message);
      this.provider = null;
    }
  }

  /**
   * 生成文档总结
   * @param {string} content - 文档内容
   * @param {object} options - 总结选项
   * @returns {Promise<object>} 总结结果
   */
  async summarize(content, options = {}) {
    // 尝试使用 LLM
    if (this.provider && await this.provider.isAvailable()) {
      try {
        return await this.provider.summarize(content, options);
      } catch (error) {
        console.warn('⚠️ LLM 总结失败，降级到基础算法:', error.message);
      }
    }

    // 降级到基础算法
    return {
      summary: extractSummary(content, options.maxLength || 500),
      provider: 'basic',
      model: 'algorithm'
    };
  }

  /**
   * 提取关键词
   * @param {string} content - 文档内容
   * @param {number} count - 关键词数量
   * @returns {Promise<string[]>} 关键词列表
   */
  async getKeywords(content, count = 5) {
    // 尝试使用 LLM
    if (this.provider && await this.provider.isAvailable()) {
      try {
        return await this.provider.extractKeywords(content, count);
      } catch (error) {
        console.warn('⚠️ LLM 关键词提取失败，降级到基础算法:', error.message);
      }
    }

    // 降级到基础算法
    return extractKeywords(content, count);
  }

  /**
   * 获取提供商信息
   * @returns {object} 提供商信息
   */
  getProviderInfo() {
    if (!this.provider) {
      return {
        provider: 'basic',
        model: 'algorithm',
        available: true
      };
    }

    return this.provider.getInfo();
  }

  /**
   * 切换提供商
   * @param {string} providerType - 提供商类型
   * @param {object} config - 配置
   */
  switchProvider(providerType, config = {}) {
    try {
      const type = (providerType || '').toLowerCase();
      const ProviderClass = PROVIDER_MAP[type];

      if (ProviderClass) {
        this.provider = new ProviderClass({ ...this.config, ...config });
      } else {
        this.provider = null;
      }
      return true;
    } catch (error) {
      console.error('切换提供商失败:', error.message);
      return false;
    }
  }
}

module.exports = SummaryService;
