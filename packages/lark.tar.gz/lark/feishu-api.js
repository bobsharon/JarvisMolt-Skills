/**
 * 飞书技能 - API 客户端模块
 * 封装所有飞书开放平台的 API 调用
 */

const https = require('https');
const { URL } = require('url');
const { safeJSONParse, retry } = require('./utils');

class FeishuAPI {
  constructor(accessToken) {
    this.accessToken = accessToken;
    this.baseURL = 'https://open.feishu.cn/open-apis';
  }

  /**
   * 发送 API 请求
   */
  async request(endpoint, options = {}) {
    const url = new URL(`${this.baseURL}${endpoint}`);
    
    const requestOptions = {
      hostname: url.hostname,
      path: url.pathname + url.search,
      method: options.method || 'GET',
      headers: {
        'Authorization': `Bearer ${this.accessToken}`,
        'Content-Type': 'application/json; charset=utf-8',
        'User-Agent': `OpenClaw-Feishu-Skill/${require('./package.json').version}`,
        ...options.headers
      },
      timeout: options.timeout || 30000
    };

    return new Promise((resolve, reject) => {
      const req = https.request(requestOptions, (res) => {
        let data = '';
        res.setEncoding('utf8');
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          const result = safeJSONParse(data, { code: -1, msg: '解析失败' });
          
          if (result.code !== 0) {
            reject(new Error(`API 错误 [${result.code}]: ${result.msg}`));
          } else {
            resolve(result.data);
          }
        });
      });

      req.on('error', (err) => reject(new Error(`请求失败: ${err.message}`)));
      req.on('timeout', () => {
        req.destroy();
        reject(new Error('请求超时'));
      });

      if (options.body) {
        req.write(JSON.stringify(options.body));
      }
      req.end();
    });
  }

  // ============ 用户相关 ============

  /**
   * 获取当前用户信息
   */
  async getUserInfo() {
    return await this.request('/authen/v1/user_info');
  }

  // ============ 文档相关 ============

  /**
   * 搜索文档
   */
  async searchDocuments(query, options = {}) {
    const {
      pageSize = 20,
      pageToken = null
    } = options;

    const body = {
      query: query,
      doc_filter: {
        doc_types: []
      },
      page_size: Math.min(pageSize, 50)
    };

    let endpoint = '/search/v2/doc_wiki/search';
    if (pageToken) {
      endpoint += `?page_token=${encodeURIComponent(pageToken)}`;
    }

    const result = await this.request(endpoint, {
      method: 'POST',
      body
    });

    // 适配返回格式，保持与调用方兼容
    const files = (result.items || []).map(doc => ({
      token: doc.doc_id,
      name: doc.title,
      type: doc.doc_type === 'doc' ? 'docx' : doc.doc_type,
      url: doc.url,
      owner_name: doc.owner_id,
      edit_time: doc.update_time
    }));

    return { files, has_more: result.has_more, page_token: result.page_token };
  }

  /**
   * 获取文档元信息
   */
  async getDocumentMeta(docToken) {
    const result = await this.request('/drive/v1/metas/batch_query', {
      method: 'POST',
      body: {
        request_docs: [{ doc_token: docToken, doc_type: 'doc' }]
      }
    });
    // 返回第一个结果的 meta
    const metas = result.metas || [];
    return metas.length > 0 ? metas[0] : null;
  }

  /**
   * 获取文档内容（支持不同类型）
   */
  async getDocumentContent(docToken, docType = 'docx') {
    // 飞书文档类型：docx（新版文档）、doc（旧版）、sheet（表格）、mindnote（思维笔记）、bitable（多维表格）
    
    switch (docType) {
      case 'docx':
        return await this.getDocxContent(docToken);
      case 'sheet':
        return await this.getSheetMeta(docToken);
      case 'bitable':
        return await this.getBitableMeta(docToken);
      default:
        // 默认返回元信息
        return await this.getDocumentMeta(docToken);
    }
  }

  /**
   * 获取新版文档（docx）内容
   */
  async getDocxContent(docToken) {
    try {
      // 首先获取文档块
      const blocks = await this.request(`/docx/v1/documents/${docToken}/blocks`);
      
      // 提取文本内容
      const content = this.extractTextFromBlocks(blocks);
      
      return {
        type: 'docx',
        blocks,
        content,
        blockCount: blocks.items?.length || 0
      };
    } catch (error) {
      // 如果 docx API 失败，回退到元信息
      const meta = await this.getDocumentMeta(docToken);
      return {
        type: 'docx',
        meta,
        content: null,
        error: error.message
      };
    }
  }

  /**
   * 从文档块中提取文本
   */
  extractTextFromBlocks(blocksData) {
    if (!blocksData || !blocksData.items) return '';
    
    const texts = [];
    
    for (const block of blocksData.items) {
      const text = this.extractTextFromBlock(block);
      if (text) texts.push(text);
    }
    
    return texts.join('\n');
  }

  /**
   * 从单个块中提取文本
   */
  extractTextFromBlock(block) {
    if (!block) return '';
    
    const blockType = block.block_type;
    
    // block_type 映射（与飞书官方 API 一致，同 handlers/markdown.js BLOCK_TYPE）
    // 1=page, 2=text, 3=heading1, 4=heading2, 5=heading3,
    // 12=bullet, 13=ordered, 14=code, 15=quote

    // page（跳过，不含文本内容）
    if (blockType === 1) {
      return '';
    }

    // 文本段落
    if (blockType === 2 && block.text) {
      const elements = block.text.elements || [];
      return elements.map(e => e.text_run?.content || '').join('');
    }

    // 标题
    if (blockType === 3 && block.heading1) {
      return '# ' + this.extractTextFromBlock({ block_type: 2, text: block.heading1 });
    }
    if (blockType === 4 && block.heading2) {
      return '## ' + this.extractTextFromBlock({ block_type: 2, text: block.heading2 });
    }
    if (blockType === 5 && block.heading3) {
      return '### ' + this.extractTextFromBlock({ block_type: 2, text: block.heading3 });
    }

    // 列表
    if (blockType === 12 && block.bullet) {
      return '- ' + this.extractTextFromBlock({ block_type: 2, text: block.bullet });
    }
    if (blockType === 13 && block.ordered) {
      return '1. ' + this.extractTextFromBlock({ block_type: 2, text: block.ordered });
    }

    // 代码块
    if (blockType === 14 && block.code) {
      const code = block.code.elements?.map(e => e.text_run?.content || '').join('') || '';
      return '```\n' + code + '\n```';
    }

    // 引用
    if (blockType === 15 && block.quote) {
      return '> ' + this.extractTextFromBlock({ block_type: 2, text: block.quote });
    }
    
    return '';
  }

  /**
   * 获取表格（sheet）元信息
   */
  async getSheetMeta(spreadsheetToken) {
    return await this.request(`/sheets/v3/spreadsheets/${spreadsheetToken}`);
  }

  /**
   * 获取多维表格（bitable）元信息
   */
  async getBitableMeta(appToken) {
    return await this.request(`/bitable/v1/apps/${appToken}`);
  }

  // ============ 文件/云空间相关 ============

  /**
   * 获取我的云空间文件列表
   */
  async listMyFiles(options = {}) {
    const { 
      folderToken = '',
      pageSize = 20,
      orderBy = 'EditedTime', // EditedTime, CreatedTime
      direction = 'DESC'
    } = options;

    const params = new URLSearchParams({
      page_size: Math.min(pageSize, 200).toString(),
      order_by: orderBy,
      direction: direction
    });

    if (folderToken) {
      params.append('folder_token', folderToken);
    }

    return await this.request(`/drive/v1/files?${params.toString()}`);
  }

  // ============ 日历相关 ============

  /**
   * 获取日历列表
   */
  async getCalendars() {
    return await this.request('/calendar/v4/calendars');
  }

  /**
   * 获取日历事件
   */
  async getCalendarEvents(calendarId, options = {}) {
    const { startTime, endTime, pageSize = 50 } = options;
    
    const params = new URLSearchParams({
      page_size: pageSize.toString()
    });
    
    if (startTime) params.append('start_time', startTime.toString());
    if (endTime) params.append('end_time', endTime.toString());

    return await this.request(`/calendar/v4/calendars/${calendarId}/events?${params.toString()}`);
  }

  // ============ 辅助方法 ============

  /**
   * 带重试的请求
   */
  async requestWithRetry(endpoint, options = {}, maxRetries = 3) {
    return await retry(async () => {
      return await this.request(endpoint, options);
    }, maxRetries);
  }
}

/**
 * OAuth 授权相关 API
 */
class FeishuAuth {
  constructor(appId, appSecret) {
    this.appId = appId;
    this.appSecret = appSecret;
    this.baseURL = 'https://open.feishu.cn/open-apis';
  }

  /**
   * 生成授权 URL
   */
  generateAuthUrl(redirectUri, state = '') {
    const scope = encodeURIComponent([
      'approval:approval:readonly',
      'bitable:app',
      'calendar:calendar:readonly',
      'contact:contact.base:readonly',
      'contact:user.base:readonly',
      'docx:document',
      'drive:drive',
      'offline_access',
      'search:docs:read',
      'wiki:wiki:readonly'
    ].join(' '));

    return `https://accounts.feishu.cn/open-apis/authen/v1/authorize?client_id=${this.appId}&response_type=code&redirect_uri=${encodeURIComponent(redirectUri)}&scope=${scope}&state=${state}`;
  }

  /**
   * 用授权码换取访问令牌
   */
  async exchangeCodeForToken(code, redirectUri) {
    const url = new URL(`${this.baseURL}/authen/v2/oauth/token`);

    const postData = JSON.stringify({
      grant_type: 'authorization_code',
      client_id: this.appId,
      client_secret: this.appSecret,
      code: code,
      redirect_uri: redirectUri
    });

    return new Promise((resolve, reject) => {
      const https = require('https');
      const req = https.request({
        hostname: url.hostname,
        path: url.pathname,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        }
      }, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          const result = safeJSONParse(data, { code: -1, msg: '解析失败' });

          // v2 API 错误: {error, error_description, code: 20003}
          if (result.error) {
            reject(new Error(result.error_description || result.error));
          // v2 API 成功: 直接返回 {access_token, refresh_token, ...}
          } else if (result.access_token) {
            resolve(result);
          // v1 API 兼容: {code: 0, data: {...}}
          } else if (result.code === 0 && result.data) {
            resolve(result.data);
          } else {
            reject(new Error(result.msg || '未知错误'));
          }
        });
      });

      req.on('error', reject);
      req.write(postData);
      req.end();
    });
  }

  /**
   * 刷新访问令牌
   */
  async refreshToken(refreshToken) {
    const url = new URL(`${this.baseURL}/authen/v2/oauth/token`);

    const postData = JSON.stringify({
      grant_type: 'refresh_token',
      client_id: this.appId,
      client_secret: this.appSecret,
      refresh_token: refreshToken
    });

    return new Promise((resolve, reject) => {
      const https = require('https');
      const req = https.request({
        hostname: url.hostname,
        path: url.pathname,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        }
      }, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          const result = safeJSONParse(data, { code: -1, msg: '解析失败' });

          // v2 API 错误: {error, error_description, code: 20003}
          if (result.error) {
            reject(new Error(result.error_description || result.error));
          // v2 API 成功: 直接返回 {access_token, refresh_token, ...}
          } else if (result.access_token) {
            resolve(result);
          // v1 API 兼容: {code: 0, data: {...}}
          } else if (result.code === 0 && result.data) {
            resolve(result.data);
          } else {
            reject(new Error(result.msg || '未知错误'));
          }
        });
      });

      req.on('error', reject);
      req.write(postData);
      req.end();
    });
  }
}

module.exports = {
  FeishuAPI,
  FeishuAuth
};
