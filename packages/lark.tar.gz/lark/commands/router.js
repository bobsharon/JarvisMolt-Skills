/**
 * 命令路由器 — 解析用户输入并路由到对应处理器
 * 从 agent.js parseCommand() 提取 + 新增 Phase 1 命令
 */

function parseCommand(text) {
  if (!text || typeof text !== 'string') {
    return { action: 'unknown' };
  }

  text = text.trim();
  const lowerText = text.toLowerCase();

  // ============== Phase 1 新增命令 ==============

  // --- 多维表格 (Bitable) ---
  const bitableQueryMatch = text.match(/飞书查询表格\s+(.+?)\s+筛选\s+(.+)/i);
  if (bitableQueryMatch) {
    return { action: 'bitable-query', tableName: bitableQueryMatch[1].trim(), filter: bitableQueryMatch[2].trim() };
  }

  const bitableQuerySimple = text.match(/飞书查询表格\s+(.+)/i);
  if (bitableQuerySimple && !bitableQueryMatch) {
    return { action: 'bitable-query', tableName: bitableQuerySimple[1].trim(), filter: null };
  }

  const bitableUpdateMatch = text.match(/飞书更新表格\s+(.+?)\s+将\s+(.+?)\s+条件\s+(.+)/i);
  if (bitableUpdateMatch) {
    return {
      action: 'bitable-update',
      tableName: bitableUpdateMatch[1].trim(),
      updates: bitableUpdateMatch[2].trim(),
      filter: bitableUpdateMatch[3].trim()
    };
  }

  const bitableCreateMatch = text.match(/飞书新增记录\s+(.+?)\s+(.+=.+)/i);
  if (bitableCreateMatch) {
    return {
      action: 'bitable-create',
      tableName: bitableCreateMatch[1].trim(),
      fields: bitableCreateMatch[2].trim()
    };
  }

  const bitableStatsMatch = text.match(/飞书表格统计\s+(.+)/i);
  if (bitableStatsMatch) {
    return { action: 'bitable-stats', tableName: bitableStatsMatch[1].trim() };
  }

  // --- 知识库 (Wiki) ---
  const wikiSearchMatch = text.match(/飞书知识库搜索\s+(.+)/i);
  if (wikiSearchMatch) {
    return { action: 'wiki-search', query: wikiSearchMatch[1].trim() };
  }

  const wikiQAMatch = text.match(/飞书知识库问答\s+(.+)/i);
  if (wikiQAMatch) {
    return { action: 'wiki-qa', question: wikiQAMatch[1].trim() };
  }

  if (/^飞书知识库目录/i.test(text)) {
    const spaceMatch = text.match(/飞书知识库目录\s+(.+)/i);
    return { action: 'wiki-list', spaceName: spaceMatch ? spaceMatch[1].trim() : null };
  }

  // --- 文档变更监控 ---
  const monitorMatch = text.match(/飞书监控文档\s+(.+?)(?:\s+(每小时|每天))?$/i);
  if (monitorMatch) {
    return {
      action: 'monitor-add',
      docName: monitorMatch[1].trim(),
      frequency: monitorMatch[2] || '每小时'
    };
  }

  const unmonitorMatch = text.match(/飞书取消监控\s+(.+)/i);
  if (unmonitorMatch) {
    return { action: 'monitor-remove', docName: unmonitorMatch[1].trim() };
  }

  if (/^飞书监控列表$/i.test(text)) {
    return { action: 'monitor-list' };
  }

  // ============== Phase 2 新增命令 ==============

  // --- 会议纪要 (Meeting Actions) ---
  const meetingExtractWriteMatch = text.match(/飞书提取行动项\s+(.+?)\s+并写入\s+(.+)/i);
  if (meetingExtractWriteMatch) {
    return { action: 'meeting-extract', docName: meetingExtractWriteMatch[1].trim(), targetTable: meetingExtractWriteMatch[2].trim() };
  }

  const meetingExtractMatch = text.match(/飞书提取行动项\s+(.+)/i);
  if (meetingExtractMatch && !meetingExtractWriteMatch) {
    return { action: 'meeting-extract', docName: meetingExtractMatch[1].trim(), targetTable: null };
  }

  const meetingSummaryMatch = text.match(/飞书纪要摘要\s+(.+)/i);
  if (meetingSummaryMatch) {
    return { action: 'meeting-summary', docName: meetingSummaryMatch[1].trim() };
  }

  const meetingCompareMatch = text.match(/飞书纪要对比\s+(.+?)\s+(.+)/i);
  if (meetingCompareMatch) {
    return { action: 'meeting-compare', docName1: meetingCompareMatch[1].trim(), docName2: meetingCompareMatch[2].trim() };
  }

  // --- 跨文档分析 (Cross-Doc) ---
  const crossDocAnalyzeMatch = text.match(/飞书跨文档分析\s+(.+?)\s+范围\s+(.+)/i);
  if (crossDocAnalyzeMatch) {
    return { action: 'cross-doc-analyze', question: crossDocAnalyzeMatch[1].trim(), scope: crossDocAnalyzeMatch[2].trim() };
  }

  const crossDocAnalyzeSimple = text.match(/飞书跨文档分析\s+(.+)/i);
  if (crossDocAnalyzeSimple && !crossDocAnalyzeMatch) {
    return { action: 'cross-doc-analyze', question: crossDocAnalyzeSimple[1].trim(), scope: crossDocAnalyzeSimple[1].trim() };
  }

  const crossDocCompareMatch = text.match(/飞书对比文档\s+(.+?)\s+(.+)/i);
  if (crossDocCompareMatch) {
    return { action: 'cross-doc-compare', docName1: crossDocCompareMatch[1].trim(), docName2: crossDocCompareMatch[2].trim() };
  }

  // --- 云空间 (Drive) ---
  const driveSearchMatch = text.match(/飞书云空间搜索\s+(.+?)(?:\s+类型\s+(文档|表格|文件夹))?$/i);
  if (driveSearchMatch) {
    return { action: 'drive-search', query: driveSearchMatch[1].trim(), fileType: driveSearchMatch[2] || null };
  }

  const driveListMatch = text.match(/飞书云空间列表(?:\s+(.+))?$/i);
  if (driveListMatch) {
    return { action: 'drive-list', folderPath: driveListMatch[1] ? driveListMatch[1].trim() : null };
  }

  const driveRecentMatch = text.match(/飞书最近文件(?:\s+(\d+))?$/i);
  if (driveRecentMatch) {
    return { action: 'drive-recent', days: parseInt(driveRecentMatch[1] || '7') };
  }

  const driveDetailMatch = text.match(/飞书文件详情\s+(.+)/i);
  if (driveDetailMatch) {
    return { action: 'drive-detail', fileName: driveDetailMatch[1].trim() };
  }

  // --- AI 周报生成 ---
  if (/^飞书(?:生成)?周报$/i.test(text)) {
    return { action: 'weekly-report' };
  }

  const weeklyReportDays = text.match(/^飞书周报\s+(\d+)天$/i);
  if (weeklyReportDays) {
    return { action: 'weekly-report', days: parseInt(weeklyReportDays[1], 10) };
  }

  // ============== Phase 3 新增命令 ==============

  // --- 日程/会议智能 ---
  if (/^飞书今日日程$/i.test(text)) {
    return { action: 'calendar-today' };
  }

  if (/^飞书本周日程$/i.test(text)) {
    return { action: 'calendar-week' };
  }

  // 飞书日程 <日期> — 查看指定日期的日程
  const calendarDateMatch = text.match(/^飞书日程\s+(\d{4}-\d{2}-\d{2})$/i);
  if (calendarDateMatch) {
    return { action: 'calendar-date', date: calendarDateMatch[1] };
  }

  const calendarPrepMatch = text.match(/飞书会议准备\s+(.+)/i);
  if (calendarPrepMatch) {
    return { action: 'calendar-prep', meetingName: calendarPrepMatch[1].trim() };
  }

  // --- 审批查询 ---
  const approvalListMatch = text.match(/^飞书我的审批(?:\s+(待审|已审|全部))?$/i);
  if (approvalListMatch) {
    return { action: 'approval-list', statusFilter: approvalListMatch[1] || null };
  }

  const approvalDetailMatch = text.match(/飞书审批详情\s+(.+)/i);
  if (approvalDetailMatch) {
    return { action: 'approval-detail', instanceId: approvalDetailMatch[1].trim() };
  }

  // --- 团队仪表盘 ---
  const teamActivityMatch = text.match(/飞书团队活跃度(?:\s+(.+))?$/i);
  if (teamActivityMatch) {
    return { action: 'team-activity', timeRange: teamActivityMatch[1] ? teamActivityMatch[1].trim() : null };
  }

  const teamContribMatch = text.match(/飞书文档贡献排行(?:\s+(.+))?$/i);
  if (teamContribMatch) {
    return { action: 'team-contribution', timeRange: teamContribMatch[1] ? teamContribMatch[1].trim() : null };
  }

  // --- Markdown 双向转换 ---
  const mdExportSaveMatch = text.match(/飞书导出[Mm]arkdown\s+(.+?)\s+保存到\s+(.+)/i);
  if (mdExportSaveMatch) {
    return { action: 'md-export', docName: mdExportSaveMatch[1].trim(), savePath: mdExportSaveMatch[2].trim() };
  }

  const mdExportMatch = text.match(/飞书导出[Mm]arkdown\s+(.+)/i);
  if (mdExportMatch && !mdExportSaveMatch) {
    return { action: 'md-export', docName: mdExportMatch[1].trim(), savePath: null };
  }

  const mdImportMatch = text.match(/飞书导入[Mm]arkdown\s+(.+?)\s+到\s+(.+)/i);
  if (mdImportMatch) {
    return { action: 'md-import', filePath: mdImportMatch[1].trim(), docName: mdImportMatch[2].trim() };
  }

  const mdPreviewMatch = text.match(/飞书[Mm]arkdown预览\s+(.+)/i);
  if (mdPreviewMatch) {
    return { action: 'md-preview', docName: mdPreviewMatch[1].trim() };
  }

  // ============== 原有命令（从 agent.js 迁移） ==============

  // LLM 配置
  if (/飞书配置总结/i.test(text) || /飞书配置AI/i.test(text) || /飞书配置LLM/i.test(text)) {
    return { action: 'configure-summary', message: text };
  }

  // 配置相关
  if (lowerText.includes('飞书配置') && (lowerText.includes('app') || lowerText.includes('secret'))) {
    return { action: 'config-from-message', message: text };
  }

  if (/^飞书配置$|^飞书开始配置$/i.test(text)) {
    return { action: 'show-config-options' };
  }

  if (/飞书购买服务/i.test(text)) {
    return { action: 'show-purchase-service' };
  }

  if (/飞书旗舰版/i.test(text)) {
    return { action: 'show-enterprise-edition' };
  }

  if (/已创建/i.test(text)) {
    return { action: 'wizard-step', step: 2 };
  }

  if (/已申请/i.test(text)) {
    return { action: 'wizard-step', step: 3 };
  }

  if (/已配置/i.test(text) && !lowerText.includes('app')) {
    return { action: 'wizard-step', step: 4 };
  }

  if (/飞书暂停配置/i.test(text)) {
    return { action: 'pause-wizard' };
  }

  if (/飞书继续配置/i.test(text)) {
    return { action: 'resume-wizard' };
  }

  if (/飞书重新配置/i.test(text)) {
    return { action: 'restart-wizard' };
  }

  if (/飞书放弃配置/i.test(text)) {
    return { action: 'cancel-wizard' };
  }

  if (/^飞书配置向导/i.test(text)) {
    return { action: 'setup-wizard', step: 1 };
  }

  const stepMatch = text.match(/飞书配置步骤\s*(\d+)/i);
  if (stepMatch) {
    return { action: 'setup-wizard', step: parseInt(stepMatch[1]) };
  }

  // 授权token处理
  const authTokenMatch = text.match(/飞书授权token\s+([a-f0-9]+)/i);
  if (authTokenMatch) {
    return { action: 'auth-token', token: authTokenMatch[1] };
  }

  const authCodeMatch = text.match(/飞书授权码\s+(\w+)/i);
  if (authCodeMatch) {
    return { action: 'auth-code', code: authCodeMatch[1] };
  }

  // 授权相关
  if (/^飞书授权$|^飞书登录$/i.test(text)) {
    return { action: 'auth' };
  }

  if (/^飞书取消授权|^飞书退出|^飞书登出/i.test(text)) {
    return { action: 'logout' };
  }

  if (/^飞书授权状态|^飞书状态$/i.test(text)) {
    return { action: 'status' };
  }

  // 批量搜索（必须在通用搜索之前）
  const batchSearchMatch = text.match(/飞书批量搜索\s+(.+)/i);
  if (batchSearchMatch) {
    const queries = batchSearchMatch[1].split(/[,，、]/).map(q => q.trim());
    return { action: 'batch-search', queries };
  }

  // 批量总结（必须在通用总结之前）
  const batchSummarizeMatch = text.match(/飞书批量总结\s+(.+)/i);
  if (batchSummarizeMatch) {
    const docNames = batchSummarizeMatch[1].split(/[,，、]/).map(d => d.trim());
    return { action: 'batch-summarize', docNames };
  }

  // 批量导出
  const batchExportMatch = text.match(/飞书批量导出\s+(.+?)(?:\s+格式\s+(\w+))?$/i);
  if (batchExportMatch) {
    const docNames = batchExportMatch[1].split(/[,，、]/).map(d => d.trim());
    const format = batchExportMatch[2] || 'markdown';
    return { action: 'batch-export', docNames, format };
  }

  // 文档搜索
  const searchMatch = text.match(/(?:飞书)?\s*(?:搜索|查找|找一下)?\s*(?:飞书)?\s*(?:文档?)?\s*(.+)/i);
  if (searchMatch && (lowerText.includes('搜索') || lowerText.includes('查找') || lowerText.includes('找一下'))) {
    return { action: 'search', query: searchMatch[1].trim() };
  }

  // 列出文档
  if (/^飞书列出|^飞书我的文档|^我的飞书文档|^飞书文档列表/i.test(text)) {
    return { action: 'list' };
  }

  // 总结文档
  const summarizeMatch = text.match(/(?:飞书)?\s*(?:总结|摘要|概括|提炼)?\s*(?:飞书)?\s*(?:文档?)?\s*(.+)/i);
  if (summarizeMatch && (lowerText.includes('总结') || lowerText.includes('摘要') || lowerText.includes('概括'))) {
    return { action: 'summarize', docName: summarizeMatch[1].trim() };
  }

  // 读取文档
  const readMatch = text.match(/(?:飞书)?\s*(?:读取|打开|查看|阅读)?\s*(?:飞书)?\s*(?:文档?)?\s*(.+)/i);
  if (readMatch && (lowerText.includes('读取') || lowerText.includes('打开') || lowerText.includes('查看'))) {
    return { action: 'read', docName: readMatch[1].trim() };
  }

  // --- 购买 / 续费 ---
  if (/^飞书购买$|^飞书购买服务$/i.test(text)) {
    return { action: 'purchase' };
  }

  if (/^飞书续费$/i.test(text)) {
    return { action: 'renew' };
  }

  if (/^飞书授权状态$/i.test(text)) {
    return { action: 'license-status' };
  }

  // 套餐选择回复（数字 1~6）
  const planMatch = text.match(/^飞书购买\s*([1-6])$/i);
  if (planMatch) {
    return { action: 'purchase-plan', planIndex: parseInt(planMatch[1], 10) };
  }

  // 帮助
  if (/^飞书帮助|^飞书说明|^飞书怎么用/i.test(text)) {
    return { action: 'help' };
  }

  // 如果包含"飞书"但无法识别
  if (lowerText.includes('飞书')) {
    return { action: 'help' };
  }

  return { action: 'unknown' };
}

module.exports = { parseCommand };
