/**
 * 飞书技能 - 工具函数模块
 */

const fs = require('fs');
const path = require('path');
const https = require('https');
const crypto = require('crypto');
const os = require('os');

/**
 * 发送 HTTPS 请求
 */
function httpsRequest(options) {
  return new Promise((resolve, reject) => {
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        resolve({
          statusCode: res.statusCode,
          headers: res.headers,
          body: data
        });
      });
    });

    req.on('error', reject);
    req.on('timeout', () => {
      req.destroy();
      reject(new Error('请求超时'));
    });

    if (options.timeout) {
      req.setTimeout(options.timeout);
    }

    if (options.body) {
      req.write(options.body);
    }
    req.end();
  });
}

/**
 * 安全地解析 JSON
 */
function safeJSONParse(str, defaultValue = null) {
  try {
    return JSON.parse(str);
  } catch (e) {
    return defaultValue;
  }
}

/**
 * 格式化文件大小
 */
function formatFileSize(bytes) {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

/**
 * 格式化时间
 */
function formatTime(timestamp) {
  if (!timestamp) return '';
  const date = new Date(timestamp);
  const now = new Date();
  const diff = now - date;
  
  // 小于 1 小时
  if (diff < 3600000) {
    const minutes = Math.floor(diff / 60000);
    return minutes < 1 ? '刚刚' : `${minutes} 分钟前`;
  }
  
  // 小于 24 小时
  if (diff < 86400000) {
    const hours = Math.floor(diff / 3600000);
    return `${hours} 小时前`;
  }
  
  // 小于 7 天
  if (diff < 604800000) {
    const days = Math.floor(diff / 86400000);
    return `${days} 天前`;
  }
  
  return date.toLocaleDateString('zh-CN');
}

/**
 * 截断文本
 */
function truncate(text, maxLength = 100) {
  if (!text || text.length <= maxLength) return text;
  return text.substring(0, maxLength) + '...';
}

/**
 * 生成随机字符串
 */
function generateRandomString(length = 16) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

/**
 * 深拷贝对象
 */
function deepClone(obj) {
  return JSON.parse(JSON.stringify(obj));
}

/**
 * 防抖函数
 */
function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

/**
 * 重试函数
 */
async function retry(fn, maxRetries = 3, delay = 1000) {
  let lastError;
  
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error;
      if (i < maxRetries - 1) {
        await new Promise(resolve => setTimeout(resolve, delay * Math.pow(2, i)));
      }
    }
  }
  
  throw lastError;
}

/**
 * 简单的日志记录
 */
class Logger {
  constructor(logPath) {
    this.logPath = logPath;
    this.ensureLogDir();
  }

  ensureLogDir() {
    const dir = path.dirname(this.logPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  }

  log(level, message, data = null) {
    const timestamp = new Date().toISOString();
    const logEntry = {
      timestamp,
      level,
      message,
      data
    };
    
    const logLine = JSON.stringify(logEntry) + '\n';
    
    // 追加到日志文件
    fs.appendFileSync(this.logPath, logLine);
    
    // 同时输出到控制台（开发时）
    if (process.env.DEBUG) {
      console.log(`[${level.toUpperCase()}] ${message}`);
    }
  }

  info(message, data) {
    this.log('info', message, data);
  }

  error(message, data) {
    this.log('error', message, data);
  }

  warn(message, data) {
    this.log('warn', message, data);
  }

  debug(message, data) {
    this.log('debug', message, data);
  }
}

/**
 * 缓存管理器
 */
class Cache {
  constructor(cachePath, maxAge = 5 * 60 * 1000) { // 默认 5 分钟
    this.cachePath = cachePath;
    this.maxAge = maxAge;
    this.memory = new Map();
    this.loadFromDisk();
  }

  loadFromDisk() {
    try {
      if (fs.existsSync(this.cachePath)) {
        const data = fs.readFileSync(this.cachePath, 'utf8');
        const entries = JSON.parse(data);
        for (const [key, value] of Object.entries(entries)) {
          if (Date.now() - value.timestamp < this.maxAge) {
            this.memory.set(key, value);
          }
        }
      }
    } catch (e) {
      // 忽略加载错误
    }
  }

  saveToDisk() {
    try {
      const entries = {};
      for (const [key, value] of this.memory) {
        entries[key] = value;
      }
      fs.writeFileSync(this.cachePath, JSON.stringify(entries));
    } catch (e) {
      // 忽略保存错误
    }
  }

  get(key) {
    const entry = this.memory.get(key);
    if (!entry) return null;
    
    if (Date.now() - entry.timestamp > this.maxAge) {
      this.memory.delete(key);
      return null;
    }
    
    return entry.data;
  }

  set(key, data) {
    this.memory.set(key, {
      data,
      timestamp: Date.now()
    });
    this.saveToDisk();
  }

  clear() {
    this.memory.clear();
    if (fs.existsSync(this.cachePath)) {
      fs.unlinkSync(this.cachePath);
    }
  }
}

/**
 * 简单的文档内容提取（模拟 AI 总结）
 */
function extractSummary(content, maxLength = 500) {
  if (!content) return '暂无内容';
  
  // 移除 HTML 标签
  let text = content.replace(/<[^>]+>/g, ' ');
  
  // 移除多余空白
  text = text.replace(/\s+/g, ' ').trim();
  
  // 提取前 maxLength 个字符
  if (text.length <= maxLength) return text;
  
  // 尝试在句号处截断
  const truncated = text.substring(0, maxLength);
  const lastPeriod = truncated.lastIndexOf('。');
  
  if (lastPeriod > maxLength * 0.7) {
    return truncated.substring(0, lastPeriod + 1) + '...';
  }
  
  return truncated + '...';
}

/**
 * 提取关键词
 */
function extractKeywords(text, count = 5) {
  if (!text) return [];

  // 简单的中文分词模拟
  const commonWords = new Set(['的', '了', '是', '在', '我', '有', '和', '就', '不', '人', '都', '一', '一个', '上', '也', '很', '到', '说', '要', '去', '你', '会', '着', '没有', '看', '好', '自己', '这']);

  const words = text.split(/[\s\n，。！？、：""''（）【】《》]/);
  const freq = {};

  for (const word of words) {
    const clean = word.trim();
    if (clean.length >= 2 && !commonWords.has(clean)) {
      freq[clean] = (freq[clean] || 0) + 1;
    }
  }

  return Object.entries(freq)
    .sort((a, b) => b[1] - a[1])
    .slice(0, count)
    .map(([word]) => word);
}

/**
 * 加密工具类
 */
class TokenEncryption {
  constructor() {
    this.algorithm = 'aes-256-cbc';
    this.key = this.getMachineKey();
  }

  /**
   * 生成基于机器的唯一密钥
   */
  getMachineKey() {
    const hostname = os.hostname();
    const platform = os.platform();
    const arch = os.arch();
    const machineId = `${hostname}-${platform}-${arch}`;

    // 生成32字节密钥
    return crypto.createHash('sha256').update(machineId).digest();
  }

  /**
   * 加密数据
   */
  encrypt(data) {
    try {
      const iv = crypto.randomBytes(16);
      const cipher = crypto.createCipheriv(this.algorithm, this.key, iv);

      let encrypted = cipher.update(JSON.stringify(data), 'utf8', 'hex');
      encrypted += cipher.final('hex');

      return {
        iv: iv.toString('hex'),
        data: encrypted
      };
    } catch (error) {
      throw new Error(`加密失败: ${error.message}`);
    }
  }

  /**
   * 解密数据
   */
  decrypt(encrypted) {
    try {
      const decipher = crypto.createDecipheriv(
        this.algorithm,
        this.key,
        Buffer.from(encrypted.iv, 'hex')
      );

      let decrypted = decipher.update(encrypted.data, 'hex', 'utf8');
      decrypted += decipher.final('utf8');

      return JSON.parse(decrypted);
    } catch (error) {
      throw new Error(`解密失败: ${error.message}`);
    }
  }
}

module.exports = {
  httpsRequest,
  safeJSONParse,
  formatFileSize,
  formatTime,
  truncate,
  generateRandomString,
  deepClone,
  debounce,
  retry,
  Logger,
  Cache,
  extractSummary,
  extractKeywords,
  TokenEncryption
};
